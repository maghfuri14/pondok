export interface ProfilPondok {
  nama_pondok: string;
  alamat: string;
  pengasuh: string;
  ketua: string;
  sekretaris?: string;
  bendahara: string;
  kontak?: string;
  email?: string;
  logo?: string;
}

export interface TarifDefault {
  syahriyah_mukim: number;
  syahriyah_nduduk: number;
  syahriyah_kilatan: number;
  event_kilatan: number;
  periode_mulai?: string; // Format 'YYYY-MM', misal '2025-07'
}

export interface ArsipTarif {
  id: string;
  periode_mulai: string; // 'YYYY-MM'
  periode_selesai: string; // 'YYYY-MM'
  syahriyah_mukim: number;
  syahriyah_nduduk: number;
  syahriyah_kilatan: number;
  event_kilatan: number;
  status: 'Diarsipkan';
  diarsipkan_pada: string;
}

export type UserRole = 'super_admin' | 'admin' | 'pemilik';
export type UserStatus = 'Aktif' | 'Nonaktif';

export interface UserAccount {
  id: string;
  nama: string;
  username: string;
  password?: string;
  role: UserRole;
  status: UserStatus;
}
