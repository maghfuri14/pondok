import { ProfilPondok, TarifDefault, ArsipTarif, UserAccount } from '../types/pengaturan';

const KEY_PROFIL = 'al_hidayah_profil';
const KEY_TARIF = 'al_hidayah_tarif';
const KEY_ARSIP_TARIF = 'al_hidayah_arsip_tarif';
const KEY_USERS = 'al_hidayah_users';

export const DEFAULT_PROFIL: ProfilPondok = {
  nama_pondok: 'Pondok Al Hidayah Tertek',
  alamat: 'Jln. Mayor Bismo No 71-73 Tertek Pare Kediri',
  pengasuh: 'KH. Mujtaba Thoifur',
  ketua: 'Muhammad Maghfuri',
  sekretaris: 'Ahmad Dahlan',
  bendahara: 'Shofil Mubarok',
  kontak: '0812-3456-7890',
  email: 'alhidayah.tertek@gmail.com',
  logo: '',
};

const currentYear = new Date().getFullYear();

export const DEFAULT_TARIF: TarifDefault = {
  syahriyah_mukim: 150000,
  syahriyah_nduduk: 100000,
  syahriyah_kilatan: 75000,
  event_kilatan: 50000,
  periode_mulai: `${currentYear}-01`,
};

export const DEFAULT_ARSIP_TARIF: ArsipTarif[] = [
  {
    id: `arsip-${currentYear - 1}`,
    periode_mulai: `${currentYear - 1}-01`,
    periode_selesai: `${currentYear - 1}-12`,
    syahriyah_mukim: 125000,
    syahriyah_nduduk: 80000,
    syahriyah_kilatan: 60000,
    event_kilatan: 40000,
    status: 'Diarsipkan',
    diarsipkan_pada: `${currentYear}-01-01T00:00:00.000Z`,
  },
];

export const DEFAULT_USERS: UserAccount[] = [
  {
    id: 'user-1',
    nama: 'Muhammad Maghfuri',
    username: 'superadmin',
    password: 'admin123',
    role: 'super_admin',
    status: 'Aktif',
  },
  {
    id: 'user-2',
    nama: 'Shofil Mubarok',
    username: 'admin1',
    password: 'admin123',
    role: 'admin',
    status: 'Aktif',
  },
  {
    id: 'user-3',
    nama: 'KH. Mujtaba Thoifur',
    username: 'pengasuh',
    password: 'admin123',
    role: 'pemilik',
    status: 'Aktif',
  },
];

/** Bandingkan dua string YYYY-MM. Return <0 jika a<b, 0 jika sama, >0 jika a>b */
function compareYearMonth(a: string, b: string): number {
  return a.localeCompare(b);
}

/**
 * Ambil tarif yang berlaku untuk periode tertentu (YYYY-MM).
 *
 * Aturan:
 * - Jika yearMonth >= tarif aktif.periode_mulai → pakai tarif aktif
 * - Jika yearMonth jatuh di salah satu arsip (periode_mulai .. periode_selesai) → pakai arsip itu
 * - Fallback: tarif aktif
 */
export function getTarifForPeriod(yearMonth: string): TarifDefault {
  const active = pengaturanService.getTarif();
  const activeStart = active.periode_mulai || `${currentYear}-01`;

  // Periode aktif: dari periode_mulai sampai "tak terbatas"
  if (compareYearMonth(yearMonth, activeStart) >= 0) {
    return active;
  }

  // Cari di arsip (urutkan dari yang paling baru)
  const arsipList = pengaturanService.getArsipTarif();
  const sorted = [...arsipList].sort((a, b) =>
    compareYearMonth(b.periode_mulai, a.periode_mulai)
  );

  for (const arsip of sorted) {
    const start = arsip.periode_mulai;
    const end = arsip.periode_selesai || start;
    if (
      compareYearMonth(yearMonth, start) >= 0 &&
      compareYearMonth(yearMonth, end) <= 0
    ) {
      return {
        syahriyah_mukim: arsip.syahriyah_mukim,
        syahriyah_nduduk: arsip.syahriyah_nduduk,
        syahriyah_kilatan: arsip.syahriyah_kilatan,
        event_kilatan: arsip.event_kilatan,
        periode_mulai: arsip.periode_mulai,
      };
    }
  }

  // Tidak ketemu arsip → fallback ke tarif aktif
  return active;
}

export const pengaturanService = {
  // PROFIL PONDOK
  getProfil(): ProfilPondok {
    try {
      const data = localStorage.getItem(KEY_PROFIL);
      if (!data) return DEFAULT_PROFIL;
      return { ...DEFAULT_PROFIL, ...JSON.parse(data) };
    } catch {
      return DEFAULT_PROFIL;
    }
  },

  saveProfil(profil: ProfilPondok): void {
    localStorage.setItem(KEY_PROFIL, JSON.stringify(profil));
  },

  // TARIF AKTIF
  getTarif(): TarifDefault {
    try {
      const data = localStorage.getItem(KEY_TARIF);
      if (!data) return DEFAULT_TARIF;
      const parsed = JSON.parse(data);
      if (!parsed.periode_mulai || parsed.periode_mulai === '2025-07') {
        parsed.periode_mulai = `${currentYear}-01`;
      }
      return { ...DEFAULT_TARIF, ...parsed };
    } catch {
      return DEFAULT_TARIF;
    }
  },

  saveTarif(tarif: TarifDefault): void {
    localStorage.setItem(KEY_TARIF, JSON.stringify(tarif));
  },

  // ARSIP RIWAYAT TARIF
  getArsipTarif(): ArsipTarif[] {
    try {
      const data = localStorage.getItem(KEY_ARSIP_TARIF);
      if (!data) {
        localStorage.setItem(KEY_ARSIP_TARIF, JSON.stringify(DEFAULT_ARSIP_TARIF));
        return DEFAULT_ARSIP_TARIF;
      }
      const list = JSON.parse(data);
      if (Array.isArray(list) && list.length === 1 && list[0].id === 'arsip-2024') {
        return DEFAULT_ARSIP_TARIF;
      }
      return list;
    } catch {
      return DEFAULT_ARSIP_TARIF;
    }
  },

  saveArsipTarif(list: ArsipTarif[]): void {
    localStorage.setItem(KEY_ARSIP_TARIF, JSON.stringify(list));
  },

  // MANAJEMEN PENGGUNA
  getUsers(): UserAccount[] {
    try {
      const data = localStorage.getItem(KEY_USERS);
      if (!data) {
        localStorage.setItem(KEY_USERS, JSON.stringify(DEFAULT_USERS));
        return DEFAULT_USERS;
      }
      return JSON.parse(data);
    } catch {
      return DEFAULT_USERS;
    }
  },

  saveUsers(users: UserAccount[]): void {
    localStorage.setItem(KEY_USERS, JSON.stringify(users));
  },

  addUser(user: Omit<UserAccount, 'id'>): UserAccount {
    const users = this.getUsers();
    const exists = users.some(
      (u) => u.username.toLowerCase() === user.username.toLowerCase()
    );
    if (exists) {
      throw new Error('Username sudah digunakan');
    }
    const newUser: UserAccount = {
      ...user,
      id: `user-${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    };
    users.push(newUser);
    this.saveUsers(users);
    return newUser;
  },

  updateUser(id: string, updated: Partial<UserAccount>): void {
    const users = this.getUsers();
    const index = users.findIndex((u) => u.id === id);
    if (index === -1) {
      throw new Error('User tidak ditemukan');
    }
    if (updated.username) {
      const exists = users.some(
        (u) =>
          u.id !== id &&
          u.username.toLowerCase() === updated.username!.toLowerCase()
      );
      if (exists) {
        throw new Error('Username sudah digunakan');
      }
    }
    users[index] = { ...users[index], ...updated };
    this.saveUsers(users);
  },

  deleteUser(id: string): void {
    const users = this.getUsers();
    const target = users.find((u) => u.id === id);
    if (!target) return;
    if (target.role === 'super_admin') {
      const otherSuper = users.filter(
        (u) => u.id !== id && u.role === 'super_admin'
      );
      if (otherSuper.length === 0) {
        throw new Error('Tidak bisa menghapus super admin terakhir');
      }
    }
    const filtered = users.filter((u) => u.id !== id);
    this.saveUsers(filtered);
  },
};
