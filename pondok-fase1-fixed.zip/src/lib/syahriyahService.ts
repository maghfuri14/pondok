import {
  SyahriyahBulan,
  StatusSyahriyah,
  SyahriyahItemInput,
  SyahriyahTransaksiData,
  SyahriyahTransaksiRecord,
} from '../types/syahriyah';
import { Santri } from '../types/santri';
import { santriService } from './santriService';
import { kasService } from './kasService';
import { getTarifForPeriod, pengaturanService } from './pengaturanService';

const STORAGE_KEY = 'al_hidayah_syahriyah';
const TRANSAKSI_KEY = 'al_hidayah_syahriyah_transaksi';

/**
 * Ambil tarif syahriyah untuk kategori.
 * Jika tahun & bulan diberikan, pakai tarif yang berlaku di periode itu
 * (tagihan lama tetap tarif lama, tagihan baru pakai tarif baru).
 */
export function getTarifSyahriyah(
  kategori: string,
  tahun?: number,
  bulan?: number
): number {
  const tarif =
    tahun != null && bulan != null
      ? getTarifForPeriod(`${tahun}-${String(bulan).padStart(2, '0')}`)
      : pengaturanService.getTarif();

  switch (kategori) {
    case 'Mukim':
      return tarif.syahriyah_mukim;
    case 'Nduduk':
      return tarif.syahriyah_nduduk;
    case 'Kilatan':
      return tarif.syahriyah_kilatan;
    default:
      return tarif.syahriyah_mukim;
  }
}

function delay(ms = 200): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function generateId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

export function isBeforeEntry(tanggalMasuk: string, tahun: number, bulan: number): boolean {
  if (!tanggalMasuk) return false;
  try {
    const [entryYearStr, entryMonthStr] = tanggalMasuk.split('-');
    const entryYear = parseInt(entryYearStr, 10);
    const entryMonth = parseInt(entryMonthStr, 10);
    if (isNaN(entryYear) || isNaN(entryMonth)) return false;

    if (tahun < entryYear) return true;
    if (tahun === entryYear && bulan < entryMonth) return true;
    return false;
  } catch {
    return false;
  }
}

/**
 * Generate record syahriyah per bulan.
 * Nominal tagihan diambil dari tarif yang berlaku di bulan tersebut
 * (bukan selalu tarif aktif).
 */
export function generateMockSyahriyah(
  santriId: string,
  kategori: string,
  tahun: number
): SyahriyahBulan[] {
  const result: SyahriyahBulan[] = [];
  const charCodeSum = santriId.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0);
  const currentYear = new Date().getFullYear();
  const currentMonth = new Date().getMonth() + 1;

  for (let bulan = 1; bulan <= 12; bulan++) {
    // Tarif per periode — kunci aturan bisnis
    const nominalTagihan = getTarifSyahriyah(kategori, tahun, bulan);

    // Tahun selain current & 2025: mulai kosong
    if (tahun !== currentYear && tahun !== 2025) {
      result.push({
        tahun,
        bulan,
        nominal_tagihan: nominalTagihan,
        total_dibayar: 0,
        status: 'Belum',
      });
      continue;
    }

    const seed = (charCodeSum + bulan * 13) % 10;
    let status: StatusSyahriyah = 'Belum';
    let totalDibayar = 0;

    // Mock realistis relatif ke bulan berjalan
    if (tahun < currentYear || (tahun === currentYear && bulan < currentMonth)) {
      if (seed < 7) {
        status = 'Lunas';
        totalDibayar = nominalTagihan;
      } else if (seed < 9) {
        status = 'Sebagian';
        totalDibayar = Math.floor(nominalTagihan / 2);
      }
    } else if (tahun === currentYear && bulan === currentMonth) {
      if (seed < 4) {
        status = 'Lunas';
        totalDibayar = nominalTagihan;
      } else if (seed < 7) {
        status = 'Sebagian';
        totalDibayar = Math.floor(nominalTagihan / 2);
      }
    }
    // bulan mendatang → Belum

    result.push({
      tahun,
      bulan,
      nominal_tagihan: nominalTagihan,
      total_dibayar: totalDibayar,
      status,
    });
  }

  return result;
}

function getStoredMatrixData(): Record<string, Record<number, SyahriyahBulan[]>> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function saveMatrixData(data: Record<string, Record<number, SyahriyahBulan[]>>): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function getStoredTransaksiData(): SyahriyahTransaksiRecord[] {
  try {
    const raw = localStorage.getItem(TRANSAKSI_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function saveTransaksiData(list: SyahriyahTransaksiRecord[]): void {
  localStorage.setItem(TRANSAKSI_KEY, JSON.stringify(list));
}


/**
 * Daftar bulan (YYYY-MM) yang sudah ada pembayaran syahriyah
 * dari minimal satu santri (total_dibayar > 0).
 */
export function getSyahriyahMonthsWithPayments(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const stored: Record<string, Record<number, SyahriyahBulan[]>> = JSON.parse(raw);
    const months = new Set<string>();
    for (const santriId of Object.keys(stored)) {
      const byYear = stored[santriId];
      for (const tahunStr of Object.keys(byYear)) {
        const tahun = parseInt(tahunStr, 10);
        const records = byYear[tahun] || [];
        for (const r of records) {
          if (r.total_dibayar > 0) {
            months.add(`${r.tahun}-${String(r.bulan).padStart(2, '0')}`);
          }
        }
      }
    }
    return Array.from(months).sort();
  } catch {
    return [];
  }
}

/**
 * Update nominal_tagihan untuk bulan >= periodeMulai yang BELUM ada pembayaran.
 * Dipanggil setelah tarif baru disimpan agar tagihan kosong ikut tarif baru.
 */
export function applyNewTarifToUnpaidMonths(
  periodeMulai: string,
  getNominal: (kategori: string, tahun: number, bulan: number) => number
): number {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return 0;
    const stored: Record<string, Record<number, SyahriyahBulan[]>> = JSON.parse(raw);

    // Need santri kategori - load from santri storage
    let santriMap: Record<string, string> = {};
    try {
      const sRaw = localStorage.getItem('al_hidayah_santri');
      if (sRaw) {
        const list = JSON.parse(sRaw) as { id: string; kategori: string }[];
        list.forEach((s) => {
          santriMap[s.id] = s.kategori;
        });
      }
    } catch {
      /* ignore */
    }

    let updatedCount = 0;
    for (const santriId of Object.keys(stored)) {
      const kategori = santriMap[santriId] || 'Mukim';
      if (kategori === 'Kilatan') continue;
      const byYear = stored[santriId];
      for (const tahunStr of Object.keys(byYear)) {
        const tahun = parseInt(tahunStr, 10);
        const records = byYear[tahun] || [];
        byYear[tahun] = records.map((r) => {
          const ym = `${r.tahun}-${String(r.bulan).padStart(2, '0')}`;
          if (ym >= periodeMulai && r.total_dibayar === 0) {
            const newNominal = getNominal(kategori, r.tahun, r.bulan);
            if (newNominal !== r.nominal_tagihan) {
              updatedCount++;
              return {
                ...r,
                nominal_tagihan: newNominal,
                status: 'Belum' as StatusSyahriyah,
              };
            }
          }
          return r;
        });
      }
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
    return updatedCount;
  } catch {
    return 0;
  }
}


export const syahriyahService = {
  async getTransaksiList(): Promise<SyahriyahTransaksiRecord[]> {
    return getStoredTransaksiData();
  },

  /**
   * Matrix syahriyah.
   * PENTING: nominal_tagihan yang sudah tersimpan TIDAK di-overwrite
   * saat tarif berubah. Tagihan lama tetap pakai tarif lama.
   */
  async getSyahriyahMatrix(
    tahun: number
  ): Promise<{ santri: Santri; records: SyahriyahBulan[] }[]> {
    await delay(200);
    // Aturan bisnis: hanya Mukim & Nduduk yang bayar syahriyah bulanan.
    // Kategori Kilatan hanya bayar event kilatan.
    const santriList = (await santriService.getSantriList()).filter(
      (s) => s.kategori !== 'Kilatan'
    );
    const stored = getStoredMatrixData();

    const matrix = santriList.map((s) => {
      let records: SyahriyahBulan[];

      if (stored[s.id] && stored[s.id][tahun]) {
        // Pertahankan nominal_tagihan yang sudah tersimpan (tarif historis)
        // Hanya pastikan status konsisten dengan total_dibayar
        records = stored[s.id][tahun].map((r) => {
          let status: StatusSyahriyah = r.status;
          if (r.total_dibayar >= r.nominal_tagihan && r.nominal_tagihan > 0) {
            status = 'Lunas';
          } else if (r.total_dibayar > 0) {
            status = 'Sebagian';
          } else {
            status = 'Belum';
          }
          return { ...r, status };
        });
      } else {
        // Generate baru → pakai tarif per periode
        records = generateMockSyahriyah(s.id, s.kategori, tahun);
        if (!stored[s.id]) stored[s.id] = {};
        stored[s.id][tahun] = records;
      }

      return { santri: s, records };
    });

    saveMatrixData(stored);
    return matrix;
  },

  async simpanPembayaranSyahriyah(
    santriId: string,
    items: SyahriyahItemInput[],
    transaksiData: SyahriyahTransaksiData
  ): Promise<SyahriyahTransaksiRecord> {
    await delay(300);

    const santriList = await santriService.getSantriList();
    const santri = santriList.find((s) => s.id === santriId);
    if (!santri) {
      throw new Error('Data santri tidak ditemukan');
    }

    if (santri.kategori === 'Kilatan') {
      throw new Error(
        'Santri kategori Kilatan tidak dikenakan syahriyah bulanan. Gunakan menu Kilatan untuk pembayaran event.'
      );
    }

    if (!items.length) {
      throw new Error('Tidak ada item pembayaran yang dipilih');
    }

    for (const item of items) {
      if (item.nominal <= 0) {
        throw new Error(
          `Nominal pembayaran bulan ${item.bulan}/${item.tahun} harus lebih dari 0`
        );
      }
    }

    const storedMatrix = getStoredMatrixData();
    if (!storedMatrix[santriId]) {
      storedMatrix[santriId] = {};
    }

    items.forEach((item) => {
      if (isBeforeEntry(santri.tanggal_masuk, item.tahun, item.bulan)) {
        throw new Error(
          `Pembayaran tidak dapat dilakukan untuk bulan ${item.bulan} tahun ${item.tahun} karena sebelum tanggal santri masuk (${santri.tanggal_masuk})`
        );
      }

      let yearRecords = storedMatrix[santriId][item.tahun];
      if (!yearRecords) {
        yearRecords = generateMockSyahriyah(santriId, santri.kategori, item.tahun);
      }

      const index = yearRecords.findIndex((r) => r.bulan === item.bulan);
      if (index !== -1) {
        const currentRecord = yearRecords[index];
        const newTotalDibayar = currentRecord.total_dibayar + item.nominal;
        let newStatus: StatusSyahriyah = 'Belum';

        if (newTotalDibayar >= currentRecord.nominal_tagihan) {
          newStatus = 'Lunas';
        } else if (newTotalDibayar > 0) {
          newStatus = 'Sebagian';
        }

        yearRecords[index] = {
          ...currentRecord,
          total_dibayar: newTotalDibayar,
          status: newStatus,
        };
      }
      storedMatrix[santriId][item.tahun] = yearRecords;
    });

    saveMatrixData(storedMatrix);

    const totalItems = items.reduce((sum, i) => sum + i.nominal, 0);
    const totalIuranLain = (transaksiData.iuran_tambahan || []).reduce(
      (sum, i) => sum + i.nominal,
      0
    );
    const totalPembayaran = totalItems + totalIuranLain;

    const newRecord: SyahriyahTransaksiRecord = {
      id: generateId('st'),
      santri_id: santri.id,
      santri_nama: santri.nama,
      santri_nis: santri.nis,
      items,
      transaksi_data: transaksiData,
      total_pembayaran: totalPembayaran,
      created_at: new Date().toISOString(),
    };

    const storedTransaksi = getStoredTransaksiData();
    saveTransaksiData([newRecord, ...storedTransaksi]);

    const bulanNames = [
      'Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun',
      'Jul', 'Ags', 'Sep', 'Okt', 'Nov', 'Des',
    ];
    const bulanSummary = items
      .map((it) => `${bulanNames[it.bulan - 1]} ${it.tahun}`)
      .join(', ');

    let kasKeterangan = `Syahriyah ${santri.nama} (${bulanSummary})`;
    if (transaksiData.iuran_tambahan && transaksiData.iuran_tambahan.length > 0) {
      const iuranStr = transaksiData.iuran_tambahan.map((i) => i.nama).join(', ');
      kasKeterangan += ` + ${iuranStr}`;
    }
    if (transaksiData.keterangan?.trim()) {
      kasKeterangan += ` (${transaksiData.keterangan.trim()})`;
    }

    await kasService.createKas({
      jenis: 'Pemasukan',
      kategori_nama: 'Syahriyah',
      tanggal: transaksiData.tanggal_bayar,
      nominal: totalPembayaran,
      keterangan: kasKeterangan,
    });

    return newRecord;
  },
};
