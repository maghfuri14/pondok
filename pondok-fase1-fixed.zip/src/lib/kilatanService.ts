import {
  KilatanEvent,
  EventKilatan,
  StatusKilatan,
  KilatanItemInput,
  KilatanTransaksiData,
  KilatanTransaksiRecord,
} from '../types/kilatan';
import { Santri } from '../types/santri';
import { santriService } from './santriService';
import { kasService } from './kasService';
import { getTarifForPeriod, pengaturanService } from './pengaturanService';

const STORAGE_KEY = 'al_hidayah_kilatan';
const TRANSAKSI_KEY = 'al_hidayah_kilatan_transaksi';

export const KILATAN_EVENTS: EventKilatan[] = [
  'Jumadil Ula',
  'Maulid',
  'Romadhon',
  'Dzulhijjah',
];

/** Bulan representatif untuk tiap event (untuk lookup tarif periode) */
const EVENT_MONTH_MAP: Record<EventKilatan, number> = {
  Romadhon: 3,
  Dzulhijjah: 6,
  Maulid: 9,
  'Jumadil Ula': 11,
};

/**
 * Tarif kilatan aktif (tarif terbaru).
 * Untuk UI yang menampilkan tarif "saat ini".
 */
export function getTarifKilatan(): number {
  return pengaturanService.getTarif().event_kilatan;
}

/**
 * Tarif kilatan untuk event di tahun tertentu
 * (menghormati arsip tarif / periode).
 */
export function getTarifKilatanForEvent(tahun: number, event: EventKilatan): number {
  const bulan = EVENT_MONTH_MAP[event] || 1;
  const yearMonth = `${tahun}-${String(bulan).padStart(2, '0')}`;
  return getTarifForPeriod(yearMonth).event_kilatan;
}

/** @deprecated Gunakan getTarifKilatan() — dibiarkan agar import lama tidak putus */
export const DEFAULT_KILATAN_TARIF = 50000;

function delay(ms = 200): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function generateId(prefix: string): string {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).slice(2, 9)}`;
}

export function isKilatanBeforeEntry(
  tanggalMasuk: string,
  tahun: number,
  event: EventKilatan
): boolean {
  if (!tanggalMasuk) return false;
  try {
    const [entryYearStr, entryMonthStr] = tanggalMasuk.split('-');
    const entryYear = parseInt(entryYearStr, 10);
    const entryMonth = parseInt(entryMonthStr, 10);
    if (isNaN(entryYear) || isNaN(entryMonth)) return false;

    if (tahun < entryYear) return true;
    if (tahun > entryYear) return false;

    const evMonth = EVENT_MONTH_MAP[event] || 1;
    return evMonth < entryMonth;
  } catch {
    return false;
  }
}

/**
 * Buat struktur event kilatan kosong untuk satu tahun (belum ada pembayaran).
 * Tidak mengenerate tagihan fiktif — dipakai saat pencatatan pembayaran pertama.
 */
export function createEmptyKilatanYear(tahun: number): KilatanEvent[] {
  return KILATAN_EVENTS.map((event) => ({
    tahun,
    event,
    nominal_tagihan: getTarifKilatanForEvent(tahun, event),
    total_dibayar: 0,
    status: 'Belum' as StatusKilatan,
  }));
}

/** @deprecated Gunakan createEmptyKilatanYear — tidak lagi mengisi mock pembayaran */
export function generateMockKilatan(_santriId: string, tahun: number): KilatanEvent[] {
  return createEmptyKilatanYear(tahun);
}

function getStoredMatrixData(): Record<string, Record<number, KilatanEvent[]>> {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return {};
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

function saveMatrixData(data: Record<string, Record<number, KilatanEvent[]>>): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}

function getStoredTransaksiData(): KilatanTransaksiRecord[] {
  try {
    const raw = localStorage.getItem(TRANSAKSI_KEY);
    if (!raw) return [];
    return JSON.parse(raw);
  } catch {
    return [];
  }
}

function saveTransaksiData(list: KilatanTransaksiRecord[]): void {
  localStorage.setItem(TRANSAKSI_KEY, JSON.stringify(list));
}


/**
 * Daftar bulan (YYYY-MM) yang sudah ada pembayaran kilatan
 * (event di-map ke bulan representatif).
 */
export function getKilatanMonthsWithPayments(): string[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    const stored: Record<string, Record<number, KilatanEvent[]>> = JSON.parse(raw);
    const months = new Set<string>();
    for (const santriId of Object.keys(stored)) {
      const byYear = stored[santriId];
      for (const tahunStr of Object.keys(byYear)) {
        const records = byYear[parseInt(tahunStr, 10)] || byYear[tahunStr as unknown as number] || [];
        for (const r of records as KilatanEvent[]) {
          if (r.total_dibayar > 0) {
            const bulan = EVENT_MONTH_MAP[r.event] || 1;
            months.add(`${r.tahun}-${String(bulan).padStart(2, '0')}`);
          }
        }
      }
    }
    return Array.from(months).sort();
  } catch {
    return [];
  }
}

/**
 * Update nominal kilatan yang belum dibayar untuk periode >= periodeMulai.
 */
export function applyNewKilatanTarifToUnpaid(
  periodeMulai: string,
  getNominal: (tahun: number, event: EventKilatan) => number
): number {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return 0;
    const stored: Record<string, Record<number, KilatanEvent[]>> = JSON.parse(raw);
    let updatedCount = 0;
    for (const santriId of Object.keys(stored)) {
      const byYear = stored[santriId];
      for (const tahunStr of Object.keys(byYear)) {
        const tahun = parseInt(tahunStr, 10);
        const records = byYear[tahun] || [];
        byYear[tahun] = records.map((r) => {
          const bulan = EVENT_MONTH_MAP[r.event] || 1;
          const ym = `${r.tahun}-${String(bulan).padStart(2, '0')}`;
          if (ym >= periodeMulai && r.total_dibayar === 0) {
            const newNominal = getNominal(r.tahun, r.event);
            if (newNominal !== r.nominal_tagihan) {
              updatedCount++;
              return {
                ...r,
                nominal_tagihan: newNominal,
                status: 'Belum' as StatusKilatan,
              };
            }
          }
          return r;
        });
      }
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(stored));
    return updatedCount;
  } catch {
    return 0;
  }
}


export const kilatanService = {
  /**
   * Matrix kilatan.
   * nominal_tagihan yang sudah tersimpan TIDAK di-overwrite saat tarif berubah.
   */
  /**
   * Matrix kilatan: hanya menampilkan santri yang pernah ikut/bayar
   * di tahun tersebut (total_dibayar > 0 pada minimal satu event).
   * Tidak mengenerate tagihan otomatis untuk semua santri.
   */
  async getKilatanMatrix(
    tahun: number
  ): Promise<{ santri: Santri; records: KilatanEvent[] }[]> {
    await delay(200);
    const santriList = await santriService.getSantriList();
    const stored = getStoredMatrixData();

    const matrix: { santri: Santri; records: KilatanEvent[] }[] = [];

    for (const s of santriList) {
      const yearRecords = stored[s.id]?.[tahun];
      if (!yearRecords || yearRecords.length === 0) continue;

      // Hanya yang pernah ada pembayaran
      const hasPayment = yearRecords.some((r) => r.total_dibayar > 0);
      if (!hasPayment) continue;

      const records = yearRecords.map((r) => {
        let status: StatusKilatan = r.status;
        if (r.total_dibayar >= r.nominal_tagihan && r.nominal_tagihan > 0) {
          status = 'Lunas';
        } else if (r.total_dibayar > 0) {
          status = 'Sebagian';
        } else {
          status = 'Belum';
        }
        return { ...r, status };
      });

      matrix.push({ santri: s, records });
    }

    return matrix;
  },

  async simpanPembayaranKilatan(
    santriId: string,
    items: KilatanItemInput[],
    transaksiData: KilatanTransaksiData
  ): Promise<KilatanTransaksiRecord> {
    await delay(300);

    const santriList = await santriService.getSantriList();
    const santri = santriList.find((s) => s.id === santriId);
    if (!santri) {
      throw new Error('Data santri tidak ditemukan');
    }

    if (!items.length) {
      throw new Error('Tidak ada item pembayaran yang dipilih');
    }

    for (const item of items) {
      if (item.nominal <= 0) {
        throw new Error(`Nominal pembayaran event ${item.event} harus lebih dari 0`);
      }
    }

    const storedMatrix = getStoredMatrixData();
    if (!storedMatrix[santriId]) {
      storedMatrix[santriId] = {};
    }

    items.forEach((item) => {
      if (isKilatanBeforeEntry(santri.tanggal_masuk, item.tahun, item.event)) {
        throw new Error(
          `Pembayaran tidak dapat dilakukan untuk ${item.event} tahun ${item.tahun} karena sebelum tanggal santri masuk (${santri.tanggal_masuk})`
        );
      }

      let yearRecords = storedMatrix[santriId][item.tahun];
      if (!yearRecords) {
        yearRecords = createEmptyKilatanYear(item.tahun);
      }

      const index = yearRecords.findIndex((r) => r.event === item.event);
      if (index !== -1) {
        const currentRecord = yearRecords[index];
        const newTotalDibayar = currentRecord.total_dibayar + item.nominal;
        let newStatus: StatusKilatan = 'Belum';

        if (newTotalDibayar >= currentRecord.nominal_tagihan) {
          newStatus = 'Lunas';
        } else if (newTotalDibayar > 0) {
          newStatus = 'Sebagian';
        }

        yearRecords[index] = {
          ...currentRecord,
          total_dibayar: newTotalDibayar,
          status: newStatus,
        };
      }
      storedMatrix[santriId][item.tahun] = yearRecords;
    });

    saveMatrixData(storedMatrix);

    const totalItems = items.reduce((sum, i) => sum + i.nominal, 0);
    const totalIuranLain = (transaksiData.iuran_tambahan || []).reduce(
      (sum, i) => sum + i.nominal,
      0
    );
    const totalPembayaran = totalItems + totalIuranLain;

    const newRecord: KilatanTransaksiRecord = {
      id: generateId('kt'),
      santri_id: santri.id,
      santri_nama: santri.nama,
      santri_nis: santri.nis,
      items,
      transaksi_data: transaksiData,
      total_pembayaran: totalPembayaran,
      created_at: new Date().toISOString(),
    };

    const storedTransaksi = getStoredTransaksiData();
    saveTransaksiData([newRecord, ...storedTransaksi]);

    const eventSummary = items.map((it) => `${it.event} ${it.tahun}`).join(', ');
    let kasKeterangan = `Kilatan ${santri.nama} (${eventSummary})`;
    if (transaksiData.iuran_tambahan && transaksiData.iuran_tambahan.length > 0) {
      const iuranStr = transaksiData.iuran_tambahan.map((i) => i.nama).join(', ');
      kasKeterangan += ` + ${iuranStr}`;
    }
    if (transaksiData.keterangan?.trim()) {
      kasKeterangan += ` (${transaksiData.keterangan.trim()})`;
    }

    await kasService.createKas({
      jenis: 'Pemasukan',
      kategori_nama: 'Kilatan',
      tanggal: transaksiData.tanggal_bayar,
      nominal: totalPembayaran,
      keterangan: kasKeterangan,
    });

    return newRecord;
  },
};
