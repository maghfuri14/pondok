# Pondok Al Hidayah — Sistem Manajemen Pondok Pesantren

Aplikasi web untuk mengelola data santri, pendaftaran, syahriyah (iuran bulanan), kilatan, buku kas, dan laporan keuangan Pondok Al Hidayah Tertek, Pare, Kediri.

## Stack

- React 19 + TypeScript
- Vite
- Tailwind CSS v4
- React Router
- Recharts, jsPDF, xlsx, Lucide React

## Fitur Utama

| Modul | Keterangan |
|-------|----------|
| **Dashboard** | Ringkasan santri, kas, tren |
| **Data Santri** | CRUD santri (Mukim / Nduduk / Kilatan) |
| **Pendaftaran** | Calon santri → konversi ke santri aktif |
| **Syahriyah** | Matrix pembayaran bulanan + kwitansi PDF |
| **Kilatan** | Iuran event + kwitansi PDF |
| **Kas** | Buku kas (terintegrasi otomatis dari pembayaran) |
| **Laporan** | Laporan keuangan & syahriyah + export |
| **Pengaturan** | Profil, tarif + arsip, user, iuran, backup |

## Aturan Tarif

- Saat tarif diubah di Pengaturan, tarif lama **otomatis diarsipkan**.
- Tagihan yang sudah ada pembayaran **tetap memakai tarif lama**.
- Tagihan yang belum dibayar (bulan >= periode baru) di-update ke **tarif baru**.
- **Perubahan tarif hanya boleh** untuk bulan yang belum ada pembayaran dari santri mana pun (syahriyah & kilatan).
- Lookup berdasarkan periode (`YYYY-MM`).

## Integrasi Antar Fitur

- Bayar Syahriyah / Kilatan → otomatis create entri Kas (Pemasukan)
- Konversi Pendaftaran → create Santri baru
- Tarif di Pengaturan dipakai Syahriyah & Kilatan sesuai periode

## Menjalankan Lokal

```bash
npm install --legacy-peer-deps
# atau
bun install

npm run dev
```

Buka http://localhost:3000

### Akun Default

| Username   | Password | Role        |
|------------|----------|-------------|
| superadmin | admin123 | Super Admin |
| admin1     | admin123 | Admin       |
| pengasuh   | admin123 | Pemilik     |

## Catatan

- Data disimpan di **localStorage** browser (prototype).
- Siap dimigrasi ke backend (Supabase / NestJS + PostgreSQL).
