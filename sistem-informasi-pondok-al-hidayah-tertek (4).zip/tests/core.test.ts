import { beforeEach, test } from 'node:test';
import assert from 'node:assert/strict';
import { installLocalStorage } from './helpers/localStorage';
import {
  KEY_NOMOR_KUITANSI,
  hasRiwayatPembayaran,
  isNominalValid,
  nextNomorKuitansi,
} from '../src/lib/core';

beforeEach(() => {
  installLocalStorage();
});

test('isNominalValid hanya menerima rupiah bulat lebih dari 0', () => {
  assert.equal(isNominalValid(1), true);
  assert.equal(isNominalValid(150000), true);
  assert.equal(isNominalValid(0), false);
  assert.equal(isNominalValid(-1), false);
  assert.equal(isNominalValid(1.5), false);
  assert.equal(isNominalValid(Number.NaN), false);
});

test('nextNomorKuitansi berurutan per tahun', () => {
  const storage = installLocalStorage();
  assert.equal(nextNomorKuitansi(2026), 'AH/2026/0001');
  assert.equal(nextNomorKuitansi(2026), 'AH/2026/0002');
  assert.equal(nextNomorKuitansi(2027), 'AH/2027/0001');
  assert.deepEqual(JSON.parse(storage.getItem(KEY_NOMOR_KUITANSI) as string), {
    '2026': 2,
    '2027': 1,
  });
});

test('nextNomorKuitansi merekonsiliasi counter dengan nomor yang sudah terpakai', () => {
  const storage = installLocalStorage();
  storage.setItem(
    'al_hidayah_syahriyah_transaksi',
    JSON.stringify([{ id: 'st-1', nomor_kuitansi: 'AH/2026/0007' }])
  );
  storage.setItem(
    'al_hidayah_kilatan_transaksi',
    JSON.stringify([{ id: 'kt-1', nomor_kuitansi: 'AH/2026/0003' }])
  );
  storage.setItem(KEY_NOMOR_KUITANSI, JSON.stringify({ '2026': 2 }));

  assert.equal(nextNomorKuitansi(2026), 'AH/2026/0008');
  assert.equal(nextNomorKuitansi(2026), 'AH/2026/0009');
});

test('hasRiwayatPembayaran mendeteksi pembayaran di matriks dan transaksi iuran', () => {
  const storage = installLocalStorage();
  assert.equal(hasRiwayatPembayaran('s1'), false);

  storage.setItem(
    'al_hidayah_syahriyah',
    JSON.stringify({ s1: { 2026: [{ total_dibayar: 1000 }] } })
  );
  assert.equal(hasRiwayatPembayaran('s1'), true);

  storage.clear();
  storage.setItem('al_hidayah_iuran_pembayaran', JSON.stringify([{ santri_id: 's2' }]));
  assert.equal(hasRiwayatPembayaran('s2'), true);
});
