import React from 'react';
import { CheckCircle2, Download, Printer, X, Plus } from 'lucide-react';
import {
  generateKwitansiPdf,
  printKwitansiHvsHtml,
  printKwitansiThermalHtml,
  terbilang,
  getKwitansiConfig,
} from '../../lib/pdfHelper';
import { pengaturanService } from '../../lib/pengaturanService';
import { kopSuratService } from '../../lib/kopSuratService';
import { formatRupiah } from '../../lib/formatter';

export interface StrukItem {
  deskripsi: string;
  nominal: number;
}

export interface StrukData {
  idTransaksi: string;
  tipe: 'Syahriyah' | 'Kilatan' | 'Iuran' | 'Lainnya';
  namaPembayar: string;
  nisPembayar?: string;
  kategoriPembayar?: string;
  tanggalBayar: string;
  metode: string;
  items: StrukItem[];
  iuranTambahan?: StrukItem[];
  totalPembayaran: number;
  keterangan?: string;
  rawRecord?: any;
  santriObj?: any;
}

interface StrukPembayaranCardProps {
  data: StrukData;
  onClose: () => void;
  onNewPayment?: () => void;
}

export const StrukPembayaranCard: React.FC<StrukPembayaranCardProps> = ({
  data,
  onClose,
  onNewPayment,
}) => {
  const profil = pengaturanService.getProfil();
  const config = getKwitansiConfig();

  const themeColor = config.hvs.warna_tema || '#059669';
  const kopDesainAktif = config.gunakan_kop_desain && kopSuratService.isAktif();
  const kopDesainImg = kopDesainAktif ? kopSuratService.getImage() : null;
  const kopLines = (config.kop_surat || '').split('\n').filter((l) => l.trim());

  const handleDownloadPdf = () => {
    if (data.rawRecord) {
      generateKwitansiPdf(
        data.rawRecord,
        data.santriObj || {
          nama: data.namaPembayar,
          nis: data.nisPembayar,
          kategori: data.kategoriPembayar,
        }
      );
    } else {
      generateKwitansiPdf({
        idTransaksi: data.idTransaksi,
        tipe: data.tipe === 'Iuran' ? 'Lainnya' : data.tipe,
        santri: data.santriObj || {
          nama: data.namaPembayar,
          nis: data.nisPembayar || '-',
          kategori: data.kategoriPembayar || 'Umum',
        },
        tanggalBayar: data.tanggalBayar,
        metode: data.metode,
        items: data.items,
        iuranTambahan: data.iuranTambahan || [],
        totalPembayaran: data.totalPembayaran,
        keterangan: data.keterangan || '',
      });
    }
  };

  const handlePrintHvs = () => {
    if (data.rawRecord) {
      printKwitansiHvsHtml(
        data.rawRecord,
        data.santriObj || {
          nama: data.namaPembayar,
          nis: data.nisPembayar,
          kategori: data.kategoriPembayar,
        }
      );
    } else {
      printKwitansiHvsHtml({
        idTransaksi: data.idTransaksi,
        tipe: data.tipe === 'Iuran' ? 'Lainnya' : data.tipe,
        santri: data.santriObj || {
          nama: data.namaPembayar,
          nis: data.nisPembayar || '-',
          kategori: data.kategoriPembayar || 'Umum',
        },
        tanggalBayar: data.tanggalBayar,
        metode: data.metode,
        items: data.items,
        iuranTambahan: data.iuranTambahan || [],
        totalPembayaran: data.totalPembayaran,
        keterangan: data.keterangan || '',
      });
    }
  };

  const handlePrintThermal = () => {
    if (data.rawRecord) {
      printKwitansiThermalHtml(
        data.rawRecord,
        data.santriObj || {
          nama: data.namaPembayar,
          nis: data.nisPembayar,
          kategori: data.kategoriPembayar,
        }
      );
    } else {
      printKwitansiThermalHtml({
        idTransaksi: data.idTransaksi,
        tipe: data.tipe === 'Iuran' ? 'Lainnya' : data.tipe,
        santri: data.santriObj || {
          nama: data.namaPembayar,
          nis: data.nisPembayar || '-',
          kategori: data.kategoriPembayar || 'Umum',
        },
        tanggalBayar: data.tanggalBayar,
        metode: data.metode,
        items: data.items,
        iuranTambahan: data.iuranTambahan || [],
        totalPembayaran: data.totalPembayaran,
        keterangan: data.keterangan || '',
      });
    }
  };

  const allItems = [...data.items, ...(data.iuranTambahan || [])];
  const tampilkanPengasuh = config.hvs.tampilkan_pengasuh || config.thermal.tampilkan_pengasuh;
  const tampilkanTtd = config.hvs.tampilkan_tanda_tangan || config.thermal.tampilkan_tanda_tangan;

  return (
    <>
      {/* 1. Standard App Modal Header */}
      <div className="flex items-center justify-between px-6 py-4 border-b border-[#E2E8F0] bg-slate-50 shrink-0">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          </div>
          <div>
            <h2 className="text-base sm:text-lg font-bold text-[#0F172A]">
              Pembayaran Berhasil Dicatat
            </h2>
            <p className="text-xs text-slate-500">
              Bukti transaksi sah telah dibukukan otomatis ke Buku Kas
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="p-1.5 rounded-lg text-slate-400 hover:text-slate-600 hover:bg-slate-200/60 transition-colors cursor-pointer"
          title="Tutup"
        >
          <X className="w-5 h-5" />
        </button>
      </div>

      {/* 2. Standard Scrollable Modal Body (Desain Format Kwitansi Pengaturan) */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-slate-100/70">
        <div className="bg-white rounded-xl border border-slate-200 shadow-md p-6 max-w-xl mx-auto space-y-4 font-sans text-xs text-slate-800">
          {/* Header Kop Surat (Format Pengaturan Kwitansi) */}
          {kopDesainImg ? (
            <img
              src={kopDesainImg}
              alt="Kop Surat"
              className="w-full max-h-24 object-contain mx-auto mb-2 pb-2 border-b-2"
              style={{ borderColor: themeColor }}
            />
          ) : (
            <div
              className="pb-3 border-b-2"
              style={{ borderColor: themeColor }}
            >
              {kopLines.length > 0 ? (
                kopLines.map((l, i) => (
                  <div
                    key={i}
                    className={i === 0 ? 'font-bold text-base sm:text-lg' : 'text-xs text-slate-600'}
                    style={i === 0 ? { color: themeColor } : undefined}
                  >
                    {l}
                  </div>
                ))
              ) : (
                <>
                  <div className="font-bold text-base sm:text-lg" style={{ color: themeColor }}>
                    {profil.nama_pondok || 'PONDOK PESANTREN AL HIDAYAH TERTEK'}
                  </div>
                  <div className="text-xs text-slate-600">
                    {profil.alamat || 'Jln. Mayor Bismo No 71-73 Tertek Pare Kediri'}
                  </div>
                  {profil.kontak && (
                    <div className="text-[11px] text-slate-500">
                      Telp: {profil.kontak} {profil.email ? `| Email: ${profil.email}` : ''}
                    </div>
                  )}
                </>
              )}
              {tampilkanPengasuh && (
                <div className="text-[11px] text-slate-400 mt-1">
                  Pengasuh: {profil.pengasuh || '-'}
                </div>
              )}
            </div>
          )}

          {/* Judul Kwitansi & Nomor Transaksi */}
          <div className="text-center pt-1">
            <h3 className="text-sm font-bold text-slate-900 tracking-wide uppercase">
              {config.judul_kwitansi || 'KWITANSI PEMBAYARAN'}
            </h3>
            <p className="text-[11px] text-slate-500 font-mono">
              No: {data.idTransaksi}
            </p>
          </div>

          {/* Informasi Santri & Transaksi (Grid Format Kwitansi) */}
          <div className="bg-slate-50 border border-slate-200 rounded-lg p-3 grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
            <div className="space-y-1">
              <div>
                <span className="text-slate-500 font-medium">Telah Terima Dari : </span>
                <span className="font-bold text-slate-900">{data.namaPembayar}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium">NIS / Kategori : </span>
                <span className="font-medium text-slate-800">
                  {data.nisPembayar || '-'} ({data.kategoriPembayar || 'Santri'})
                </span>
              </div>
            </div>
            <div className="space-y-1 sm:text-right">
              <div>
                <span className="text-slate-500 font-medium">Tanggal Bayar : </span>
                <span className="font-semibold text-slate-900">{data.tanggalBayar}</span>
              </div>
              <div>
                <span className="text-slate-500 font-medium">Metode Pembayaran : </span>
                <span className="font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200 text-[11px]">
                  {data.metode || 'Tunai'}
                </span>
              </div>
            </div>
          </div>

          {/* Tabel Rincian Pembayaran */}
          <div className="overflow-hidden border border-slate-200 rounded-lg">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr className="text-white font-bold" style={{ backgroundColor: themeColor }}>
                  <th className="px-3 py-2 w-10 text-center border-r border-white/20">No</th>
                  <th className="px-3 py-2 border-r border-white/20">Rincian Pembayaran</th>
                  <th className="px-3 py-2 text-right w-36">Nominal</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 bg-white">
                {allItems.map((item, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/50">
                    <td className="px-3 py-2 text-center text-slate-500 font-mono">{idx + 1}</td>
                    <td className="px-3 py-2 font-medium text-slate-800">{item.deskripsi}</td>
                    <td className="px-3 py-2 text-right font-mono font-bold text-slate-900">
                      {formatRupiah(item.nominal)}
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-100 font-bold border-t-2 border-slate-300">
                  <td colSpan={2} className="px-3 py-2.5 text-right text-slate-900 uppercase">
                    Total Pembayaran
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono text-emerald-700 text-sm">
                    {formatRupiah(data.totalPembayaran)}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>

          {/* Terbilang (jika diaktifkan di Pengaturan) */}
          {config.tampilkan_terbilang && (
            <div className="p-2.5 rounded-lg bg-slate-50 border border-slate-200 text-xs italic text-slate-700">
              <span className="font-bold not-italic">Terbilang : </span># {terbilang(data.totalPembayaran)} #
            </div>
          )}

          {/* Catatan / Footer Kwitansi */}
          {(data.keterangan || config.footer_kwitansi) && (
            <div className="text-[11px] text-slate-500 space-y-0.5">
              {data.keterangan && (
                <div>
                  <span className="font-bold text-slate-700">Keterangan:</span> {data.keterangan}
                </div>
              )}
              {config.footer_kwitansi && (
                <div className="italic text-slate-400">
                  Catatan: {config.footer_kwitansi}
                </div>
              )}
            </div>
          )}

          {/* Area Tanda Tangan (jika diaktifkan di Pengaturan) */}
          {tampilkanTtd && (
            <div className="pt-6 flex justify-between items-end text-xs text-slate-800">
              <div className="text-center w-36">
                <div>Penyetor,</div>
                <div className="h-12" />
                <div className="border-b border-slate-400 mx-2" />
                <div className="font-semibold mt-1">{data.namaPembayar}</div>
              </div>
              <div className="text-center w-44">
                <div>
                  {(config.kota_kuitansi || 'Pare').trim()}, {data.tanggalBayar}
                </div>
                <div className="font-semibold">
                  {config.gelar_penandatangan || 'Bendahara Pondok'},
                </div>
                <div className="h-12" />
                <div className="border-b border-slate-400 mx-2" />
                <div className="font-bold mt-1">
                  {config.nama_penandatangan || profil.bendahara || 'Shofil Mubarok'}
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* 3. Standard App Modal Footer */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-3 px-6 py-4 border-t border-[#E2E8F0] bg-slate-50 shrink-0">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 w-full sm:w-auto flex-1">
          <button
            type="button"
            onClick={handlePrintHvs}
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>Print Hvs </span>
          </button>

          <button
            type="button"
            onClick={handlePrintThermal}
            className="px-3.5 py-2.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-50 text-slate-700 text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
          >
            <Printer className="w-4 h-4 text-slate-500" />
            <span>Print Thermal </span>
          </button>

          <button
            type="button"
            onClick={handleDownloadPdf}
            className="px-3.5 py-2.5 rounded-lg bg-[#059669] hover:bg-[#047857] text-white text-xs font-semibold inline-flex items-center justify-center gap-1.5 transition-colors shadow-2xs cursor-pointer"
          >
            <Download className="w-4 h-4" />
            <span>Unduh PDF </span>
          </button>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full sm:w-auto px-6 py-2.5 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold transition-colors cursor-pointer shrink-0"
        >
          Tutup
        </button>
      </div>
    </>
  );
};

export default StrukPembayaranCard;
