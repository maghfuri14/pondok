import { Santri } from '../types/santri';
import { INITIAL_MOCK_SANTRI } from './mockSantri';
import { SEED_DEMO_DATA, generateId, hasRiwayatPembayaran, readJsonStrict } from './core';

const STORAGE_KEY = 'al_hidayah_santri';
const KATEGORI_VALID = ['Mukim', 'Nduduk', 'Kilatan'];

function delay(ms = 300): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function getStoredSantri(): Santri[] {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (raw === null) {
    const seed = SEED_DEMO_DATA ? INITIAL_MOCK_SANTRI : [];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(seed));
    return seed;
  }
  return readJsonStrict<Santri[]>(STORAGE_KEY, []);
}

function saveSantriList(list: Santri[]): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

function normalizeNis(nis: string): string {
  return nis.trim().toLowerCase();
}

function validateSantri(data: { nis?: string; nama?: string; kategori?: string; tanggal_masuk?: string }) {
  if (data.nis !== undefined && !data.nis.trim()) throw new Error('NIS wajib diisi');
  if (data.nama !== undefined && !data.nama.trim()) throw new Error('Nama santri wajib diisi');
  if (data.kategori !== undefined && !KATEGORI_VALID.includes(data.kategori)) {
    throw new Error('Kategori santri tidak valid');
  }
  if (data.tanggal_masuk !== undefined && !/^\d{4}-\d{2}-\d{2}$/.test(data.tanggal_masuk)) {
    throw new Error('Tanggal masuk tidak valid');
  }
}

export const santriService = {
  async getSantriList(): Promise<Santri[]> {
    await delay(300);
    return getStoredSantri();
  },

  async getSantriById(id: string): Promise<Santri | null> {
    await delay(200);
    return getStoredSantri().find((s) => s.id === id) || null;
  },

  async checkNisUnik(nis: string, excludeId?: string): Promise<boolean> {
    await delay(100);
    const target = normalizeNis(nis);
    return !getStoredSantri().some((s) => normalizeNis(s.nis) === target && s.id !== excludeId);
  },

  async createSantri(data: Omit<Santri, 'id' | 'created_at' | 'updated_at'>): Promise<Santri> {
    await delay(300);
    validateSantri(data);
    const list = getStoredSantri();
    if (list.some((s) => normalizeNis(s.nis) === normalizeNis(data.nis))) {
      throw new Error('NIS sudah digunakan');
    }
    const now = new Date().toISOString();
    const newSantri: Santri = { ...data, id: generateId('s'), created_at: now, updated_at: now };
    saveSantriList([newSantri, ...list]);
    return newSantri;
  },

  async updateSantri(
    id: string,
    data: Partial<Omit<Santri, 'id' | 'created_at' | 'updated_at'>>
  ): Promise<Santri> {
    await delay(300);
    validateSantri(data);
    const list = getStoredSantri();
    const index = list.findIndex((s) => s.id === id);
    if (index === -1) {
      throw new Error('Data santri tidak ditemukan');
    }
    if (data.nis && list.some((s) => s.id !== id && normalizeNis(s.nis) === normalizeNis(data.nis!))) {
      throw new Error('NIS sudah digunakan');
    }
    const updated: Santri = { ...list[index], ...data, updated_at: new Date().toISOString() };
    list[index] = updated;
    saveSantriList(list);
    return updated;
  },

  /**
   * Santri yang sudah punya riwayat pembayaran TIDAK boleh dihapus,
   * karena riwayat harus tetap tampil. Gunakan status "Tidak Aktif".
   */
  async deleteSantri(id: string): Promise<void> {
    await delay(300);
    const list = getStoredSantri();
    if (!list.some((s) => s.id === id)) {
      throw new Error('Data santri tidak ditemukan');
    }
    if (hasRiwayatPembayaran(id)) {
      throw new Error(
        'Santri memiliki riwayat pembayaran sehingga tidak dapat dihapus. Ubah statusnya menjadi Tidak Aktif.'
      );
    }
    saveSantriList(list.filter((s) => s.id !== id));
  },
};
