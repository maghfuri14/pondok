import { Kas } from '../types/kas';
import { SEED_DEMO_DATA, generateId, isNominalValid, readJsonStrict, currentYmLocal } from './core';

export const KAS_STORAGE_KEY = 'al_hidayah_kas';

const yearMonth = currentYmLocal();

const MOCK_KAS: Kas[] = [
  { id: 'k1', tanggal: `${yearMonth}-01`, jenis: 'Pemasukan', kategori_nama: 'Donasi', nominal: 1000000, keterangan: 'Donasi harian hamba Allah untuk pondok', created_at: `${yearMonth}-01T08:00:00Z` },
  { id: 'k2', tanggal: `${yearMonth}-03`, jenis: 'Pengeluaran', kategori_nama: 'Listrik', nominal: 350000, keterangan: 'Pembayaran tagihan listrik PLN bulan ini', created_at: `${yearMonth}-03T10:00:00Z` },
  { id: 'k3', tanggal: `${yearMonth}-05`, jenis: 'Pemasukan', kategori_nama: 'Donasi', nominal: 3500000, keterangan: 'Infaq dari donatur utama pondok', created_at: `${yearMonth}-05T09:30:00Z` },
];

function delay(ms = 300): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function getStoredKas(): Kas[] {
  const raw = localStorage.getItem(KAS_STORAGE_KEY);
  if (raw === null) {
    const seed = SEED_DEMO_DATA ? MOCK_KAS : [];
    localStorage.setItem(KAS_STORAGE_KEY, JSON.stringify(seed));
    return seed;
  }
  return readJsonStrict<Kas[]>(KAS_STORAGE_KEY, []);
}

function saveKasList(list: Kas[]): void {
  localStorage.setItem(KAS_STORAGE_KEY, JSON.stringify(list));
}

function validateKas(data: Pick<Kas, 'tanggal' | 'jenis' | 'nominal' | 'kategori_nama'>) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(data.tanggal)) {
    throw new Error('Tanggal transaksi tidak valid');
  }
  if (data.jenis !== 'Pemasukan' && data.jenis !== 'Pengeluaran') {
    throw new Error('Jenis transaksi tidak valid');
  }
  if (!isNominalValid(data.nominal)) {
    throw new Error('Nominal harus bilangan bulat rupiah dan lebih dari 0');
  }
  if (!data.kategori_nama?.trim()) {
    throw new Error('Kategori wajib diisi');
  }
}

const SUMBER_LOCK_MSG =
  'Transaksi ini berasal dari pembayaran dan tidak dapat diubah atau dihapus dari Kas. Batalkan pembayaran dari menu asalnya.';

export const kasService = {
  async getKasList(): Promise<Kas[]> {
    await delay(300);
    return getStoredKas();
  },

  async getKasById(id: string): Promise<Kas | null> {
    await delay(200);
    return getStoredKas().find((k) => k.id === id) || null;
  },

  async createKas(data: Omit<Kas, 'id' | 'created_at'>): Promise<Kas> {
    await delay(300);
    validateKas(data);
    const list = getStoredKas();
    const newKas: Kas = {
      ...data,
      keterangan: data.keterangan?.trim() || undefined,
      id: generateId('k'),
      created_at: new Date().toISOString(),
    };
    saveKasList([newKas, ...list]);
    return newKas;
  },

  async updateKas(id: string, data: Partial<Omit<Kas, 'id' | 'created_at'>>): Promise<Kas> {
    await delay(300);
    const list = getStoredKas();
    const index = list.findIndex((k) => k.id === id);
    if (index === -1) {
      throw new Error('Data transaksi kas tidak ditemukan');
    }
    if (list[index].sumber) {
      throw new Error(SUMBER_LOCK_MSG);
    }
    const updated = { ...list[index], ...data };
    validateKas(updated);
    list[index] = updated;
    saveKasList(list);
    return updated;
  },

  async deleteKas(id: string): Promise<void> {
    await delay(300);
    const list = getStoredKas();
    const target = list.find((k) => k.id === id);
    if (!target) {
      throw new Error('Data transaksi kas tidak ditemukan');
    }
    if (target.sumber) {
      throw new Error(SUMBER_LOCK_MSG);
    }
    saveKasList(list.filter((k) => k.id !== id));
  },
};

