import { kasService } from './kasService';
import { santriService } from './santriService';
import { pendaftaranService } from './pendaftaranService';
import { syahriyahService } from './syahriyahService';
import { Kas } from '../types/kas';
import { Santri } from '../types/santri';
import { Pendaftaran } from '../types/pendaftaran';
import { isBulanDitagihkan, tahunBulanDari } from './core';

export interface LaporanKeuanganData {
  list: Kas[];
  totalPemasukan: number;
  totalPengeluaran: number;
  saldoBersih: number;
}

export interface LaporanSyahriyahRow {
  santriId: string;
  nis: string;
  nama: string;
  kategori: string;
  totalTagihan: number;
  totalDibayar: number;
  sisaTunggakan: number;
  statusTahunan: 'Lunas' | 'Sebagian' | 'Belum';
}

export const laporanService = {
  async getLaporanKeuangan(tahun: number, bulan: string, jenis: string): Promise<LaporanKeuanganData> {
    const kasList = await kasService.getKasList();

    // Tanggal diambil dari string YYYY-MM-DD agar tidak bergeser zona waktu.
    const filtered = kasList.filter((item) => {
      const tb = tahunBulanDari(item.tanggal);
      if (!tb) return false;
      if (tb.tahun !== tahun) return false;
      if (bulan !== 'Semua' && String(tb.bulan) !== bulan) return false;
      if (jenis !== 'Semua' && item.jenis !== jenis) return false;
      return true;
    });

    const totalPemasukan = filtered
      .filter((k) => k.jenis === 'Pemasukan')
      .reduce((sum, k) => sum + k.nominal, 0);
    const totalPengeluaran = filtered
      .filter((k) => k.jenis === 'Pengeluaran')
      .reduce((sum, k) => sum + k.nominal, 0);

    return {
      list: filtered,
      totalPemasukan,
      totalPengeluaran,
      saldoBersih: totalPemasukan - totalPengeluaran,
    };
  },

  async getLaporanSantri(kategori: string, status: string): Promise<Santri[]> {
    const list = await santriService.getSantriList();
    return list.filter((s) => {
      if (kategori !== 'Semua' && s.kategori !== kategori) return false;
      if (status !== 'Semua' && s.status !== status) return false;
      return true;
    });
  },

  async getLaporanPendaftaran(tahun: number, bulan: string, status: string): Promise<Pendaftaran[]> {
    const list = await pendaftaranService.getPendaftaranList();
    return list.filter((item) => {
      const tb = tahunBulanDari(item.tanggal_pendaftaran);
      if (!tb) return false;
      if (tb.tahun !== tahun) return false;
      if (bulan !== 'Semua' && String(tb.bulan) !== bulan) return false;
      if (status !== 'Semua' && item.status !== status) return false;
      return true;
    });
  },

  /**
   * Rekap syahriyah per santri untuk satu tahun.
   * Tagihan dihitung hanya untuk bulan sejak santri masuk sampai bulan berjalan.
   * Pembayaran di muka (bulan mendatang) tetap dihitung sebagai dibayar,
   * tetapi tidak menjadi tunggakan.
   */
  async getLaporanSyahriyah(tahun: number, kategori: string): Promise<LaporanSyahriyahRow[]> {
    const matrix = await syahriyahService.getSyahriyahMatrix(tahun);

    return matrix
      .filter(({ santri }) => kategori === 'Semua' || santri.kategori === kategori)
      .map(({ santri, records }) => {
        const tagihanRecords = records.filter((r) =>
          isBulanDitagihkan(santri.tanggal_masuk, r.tahun, r.bulan)
        );
        const totalTagihan = tagihanRecords.reduce((sum, r) => sum + r.nominal_tagihan, 0);
        const totalDibayar = records.reduce((sum, r) => sum + r.total_dibayar, 0);
        // Tunggakan hanya dihitung dari bulan yang sudah ditagihkan, sehingga
        // pembayaran di muka (bulan mendatang) tidak membuat status jadi Lunas.
        const dibayarUntukTagihan = tagihanRecords.reduce((sum, r) => sum + r.total_dibayar, 0);
        const sisaTunggakan = Math.max(0, totalTagihan - dibayarUntukTagihan);

        let statusTahunan: 'Lunas' | 'Sebagian' | 'Belum' = 'Belum';
        if (totalTagihan > 0 && sisaTunggakan === 0) statusTahunan = 'Lunas';
        else if (dibayarUntukTagihan > 0) statusTahunan = 'Sebagian';

        return {
          santriId: santri.id,
          nis: santri.nis,
          nama: santri.nama,
          kategori: santri.kategori,
          totalTagihan,
          totalDibayar,
          sisaTunggakan,
          statusTahunan,
        };
      });
  },
};
