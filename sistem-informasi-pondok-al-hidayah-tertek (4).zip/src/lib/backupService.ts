/**
 * Backup & restore data Pondok Al Hidayah.
 *
 * Prinsip:
 * - Hanya key data aplikasi yang dikenal yang boleh dibackup/direstore.
 * - Sesi login (auth), event toast, dan key legacy TIDAK ikut dibackup agar
 *   restore tidak menimpa/menghidupkan sesi lama.
 * - File asing atau struktur data yang rusak ditolak seluruhnya; tidak ada
 *   penulisan sebagian yang bisa membuat data setengah pulih.
 */

export const BACKUP_APP_ID = 'pondok-al-hidayah';
export const BACKUP_VERSION = 1;

export interface StorageLike {
  readonly length: number;
  key(index: number): string | null;
  getItem(key: string): string | null;
  setItem(key: string, value: string): void;
  removeItem(key: string): void;
}

export interface BackupEnvelope {
  app: typeof BACKUP_APP_ID;
  version: typeof BACKUP_VERSION;
  created_at: string;
  data: Record<string, unknown>;
}

type Validator = (value: unknown) => boolean;

interface BackupSpec {
  label: string;
  validate: Validator;
}

const isPlainObject = (value: unknown): value is Record<string, unknown> =>
  value !== null && typeof value === 'object' && !Array.isArray(value);

const isStringArray = (value: unknown): boolean =>
  Array.isArray(value) && value.every((item) => typeof item === 'string');

const arrayOfRecords =
  (requiredKeys: string[]): Validator =>
  (value: unknown): boolean =>
    Array.isArray(value) &&
    value.every(
      (item) =>
        isPlainObject(item) &&
        requiredKeys.every(
          (key) => typeof item[key] === 'string' && (item[key] as string).trim() !== ''
        )
    );

const isNomorKuitansi = (value: unknown): boolean =>
  isPlainObject(value) &&
  Object.values(value).every(
    (item) => typeof item === 'number' && Number.isFinite(item) && item >= 0
  );

const isKategoriKas = (value: unknown): boolean =>
  isPlainObject(value) && isStringArray(value.pemasukan) && isStringArray(value.pengeluaran);

const isUserArray: Validator = (value) =>
  Array.isArray(value) &&
  value.every(
    (item) =>
      isPlainObject(item) &&
      typeof item.username === 'string' &&
      item.username.trim() !== '' &&
      ['super_admin', 'admin', 'pemilik'].includes(String(item.role)) &&
      ['Aktif', 'Nonaktif'].includes(String(item.status))
  );

export const BACKUP_SPECS: Record<string, BackupSpec> = {
  al_hidayah_santri: { label: 'Data santri', validate: arrayOfRecords(['id']) },
  al_hidayah_pendaftaran: { label: 'Data pendaftaran', validate: arrayOfRecords(['id']) },
  al_hidayah_syahriyah: { label: 'Matriks syahriyah', validate: isPlainObject },
  al_hidayah_syahriyah_transaksi: {
    label: 'Transaksi syahriyah',
    validate: arrayOfRecords(['id']),
  },
  al_hidayah_kilatan: { label: 'Matriks kilatan', validate: isPlainObject },
  al_hidayah_kilatan_transaksi: {
    label: 'Transaksi kilatan',
    validate: arrayOfRecords(['id']),
  },
  al_hidayah_kas: { label: 'Buku kas', validate: arrayOfRecords(['id']) },
  al_hidayah_kategori_kas: { label: 'Kategori kas', validate: isKategoriKas },
  al_hidayah_profil: { label: 'Profil pondok', validate: isPlainObject },
  al_hidayah_tarif: { label: 'Tarif', validate: isPlainObject },
  al_hidayah_arsip_tarif: { label: 'Arsip tarif', validate: arrayOfRecords(['id']) },
  al_hidayah_users: { label: 'Akun pengguna', validate: isUserArray },
  al_hidayah_master_iuran: {
    label: 'Master iuran',
    validate: arrayOfRecords(['id', 'nama']),
  },
  al_hidayah_iuran_pembayaran: {
    label: 'Pembayaran iuran',
    validate: arrayOfRecords(['id', 'iuran_id']),
  },
  al_hidayah_iuran_tambahan: {
    label: 'Iuran tambahan',
    validate: arrayOfRecords(['id', 'nama']),
  },
  al_hidayah_nomor_kuitansi: { label: 'Nomor kuitansi', validate: isNomorKuitansi },
  al_hidayah_kwitansi_config: { label: 'Pengaturan kuitansi', validate: isPlainObject },
  al_hidayah_kop_surat: {
    label: 'Desain kop surat',
    validate: (value) =>
      isPlainObject(value) && isPlainObject(value.config), // { version, config, image }
  },
};

export const BACKUP_KEYS = Object.keys(BACKUP_SPECS);

/**
 * Key yang sengaja tidak dipulihkan. Key ini boleh ada di file backup lama,
 * tetapi nilainya tidak akan pernah ditulis kembali ke localStorage.
 */
const IGNORED_BACKUP_KEYS = new Set([
  'al_hidayah_auth_user',
  'al_hidayah_toast_event',
  'hidayah_auth_user',
  'user',
]);

export type BackupValidation =
  | { ok: true; data: Record<string, unknown>; ignored: string[] }
  | { ok: false; message: string };

const fail = (message: string): BackupValidation => ({ ok: false, message });

/** Susun objek backup dari key data yang dikenal saja. */
export function buildBackup(storage: StorageLike = localStorage): BackupEnvelope {
  const data: Record<string, unknown> = {};

  for (const key of BACKUP_KEYS) {
    const raw = storage.getItem(key);
    if (raw === null) continue;
    try {
      data[key] = JSON.parse(raw);
    } catch {
      throw new Error(
        `Data "${BACKUP_SPECS[key].label}" rusak sehingga backup tidak dapat dibuat.`
      );
    }
  }

  return {
    app: BACKUP_APP_ID,
    version: BACKUP_VERSION,
    created_at: new Date().toISOString(),
    data,
  };
}

/**
 * Validasi file backup. Mendukung format amplop baru dan format datar (backup
 * lama), tetapi selalu menolak file asing dan struktur data yang tidak valid.
 */
export function validateBackup(raw: unknown): BackupValidation {
  if (!isPlainObject(raw)) {
    return fail('File backup harus berupa objek JSON.');
  }

  let source: unknown;
  const maybeEnvelope = raw as Record<string, unknown>;

  if ('app' in maybeEnvelope || 'data' in maybeEnvelope || 'version' in maybeEnvelope) {
    if (maybeEnvelope.app !== BACKUP_APP_ID) {
      return fail('File ini bukan backup aplikasi Pondok Al Hidayah.');
    }
    if (maybeEnvelope.version !== BACKUP_VERSION) {
      return fail(
        `Versi backup (${String(maybeEnvelope.version)}) tidak didukung aplikasi ini.`
      );
    }
    source = maybeEnvelope.data;
  } else {
    // Kompatibilitas backup lama: seluruh key data berada di level atas.
    source = raw;
  }

  if (!isPlainObject(source)) {
    return fail('Struktur data backup tidak valid.');
  }

  const data: Record<string, unknown> = {};
  const ignored: string[] = [];
  const unknownKeys: string[] = [];

  for (const [key, value] of Object.entries(source)) {
    if (key in BACKUP_SPECS) {
      if (!BACKUP_SPECS[key].validate(value)) {
        return fail(`Struktur data "${BACKUP_SPECS[key].label}" tidak valid.`);
      }
      data[key] = value;
    } else if (IGNORED_BACKUP_KEYS.has(key)) {
      ignored.push(key);
    } else {
      unknownKeys.push(key);
    }
  }

  if (Object.keys(data).length === 0) {
    return fail('File backup tidak berisi data aplikasi yang dikenali.');
  }

  if (unknownKeys.length > 0) {
    return fail(
      `File backup berisi data yang tidak dikenal: ${unknownKeys.slice(0, 5).join(', ')}${
        unknownKeys.length > 5 ? ', …' : ''
      }`
    );
  }

  return { ok: true, data, ignored };
}

/**
 * Pulihkan data. Penulisan dilakukan setelah seluruh file lolos validasi dan
 * di-rollback bila ada kegagalan di tengah proses.
 */
export function restoreBackup(
  raw: unknown,
  storage: StorageLike = localStorage
): { restored: number; ignored: string[] } {
  const validation = validateBackup(raw);
  if (!validation.ok) {
    throw new Error(validation.message);
  }

  const entries = Object.entries(validation.data);
  const snapshot = entries.map(([key]) => [key, storage.getItem(key)] as const);

  try {
    for (const [key, value] of entries) {
      storage.setItem(key, JSON.stringify(value));
    }
  } catch (error) {
    for (const [key, previous] of snapshot) {
      if (previous === null) storage.removeItem(key);
      else storage.setItem(key, previous);
    }
    throw error;
  }

  return { restored: entries.length, ignored: validation.ignored };
}
