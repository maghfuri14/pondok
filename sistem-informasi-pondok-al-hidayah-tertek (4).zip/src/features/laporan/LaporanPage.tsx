import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  FileText,
  Download,
  Filter,
  RotateCcw,
  SearchX,
  Wallet,
  Users,
  UserPlus,
  CreditCard,
  Printer,
  Eye,
  X,
} from 'lucide-react';
import {
  laporanService,
  LaporanKeuanganData,
  LaporanSyahriyahRow,
} from '../../lib/laporanService';
import { Santri } from '../../types/santri';
import { Pendaftaran } from '../../types/pendaftaran';
import { formatRupiah, formatSaldo } from '../../lib/formatter';
import {
  exportToCsv,
  exportToExcel,
  exportLaporanToPdf,
  generateLaporanPdfBlobUrl,
  printLaporanPdf,
  ExportLaporanPdfParams,
} from '../../lib/exportHelper';
import { ToastContainer, showToast } from '../../components/ui/Toast';

type TabType = 'keuangan' | 'santri' | 'pendaftaran' | 'syahriyah';

const BULAN_OPTIONS = [
  { value: 'Semua', label: 'Semua Bulan' },
  { value: '1', label: 'Januari' },
  { value: '2', label: 'Februari' },
  { value: '3', label: 'Maret' },
  { value: '4', label: 'April' },
  { value: '5', label: 'Mei' },
  { value: '6', label: 'Juni' },
  { value: '7', label: 'Juli' },
  { value: '8', label: 'Agustus' },
  { value: '9', label: 'September' },
  { value: '10', label: 'Oktober' },
  { value: '11', label: 'November' },
  { value: '12', label: 'Desember' },
];

export const LaporanPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabType>('keuangan');

  // Filter States
  const currentYear = new Date().getFullYear();
  const [tahun, setTahun] = useState<number>(currentYear);
  const [bulan, setBulan] = useState<string>('Semua');
  const [jenisKeuangan, setJenisKeuangan] = useState<string>('Semua');
  const [kategoriSantri, setKategoriSantri] = useState<string>('Semua');
  const [statusSantri, setStatusSantri] = useState<string>('Semua');
  const [statusPendaftaran, setStatusPendaftaran] = useState<string>('Semua');

  // Data States
  const [isLoading, setIsLoading] = useState(true);
  const [keuanganData, setKeuanganData] = useState<LaporanKeuanganData | null>(null);
  const [santriData, setSantriData] = useState<Santri[]>([]);
  const [pendaftaranData, setPendaftaranData] = useState<Pendaftaran[]>([]);
  const [syahriyahData, setSyahriyahData] = useState<LaporanSyahriyahRow[]>([]);

  // Print & PDF Preview Modal States
  const [previewModalOpen, setPreviewModalOpen] = useState(false);
  const [previewPdfUrl, setPreviewPdfUrl] = useState<string | null>(null);
  const [previewParams, setPreviewParams] = useState<ExportLaporanPdfParams | null>(null);

  const loadActiveTabData = async () => {
    setIsLoading(true);
    try {
      if (activeTab === 'keuangan') {
        const res = await laporanService.getLaporanKeuangan(tahun, bulan, jenisKeuangan);
        setKeuanganData(res);
      } else if (activeTab === 'santri') {
        const res = await laporanService.getLaporanSantri(kategoriSantri, statusSantri);
        setSantriData(res);
      } else if (activeTab === 'pendaftaran') {
        const res = await laporanService.getLaporanPendaftaran(tahun, bulan, statusPendaftaran);
        setPendaftaranData(res);
      } else if (activeTab === 'syahriyah') {
        const res = await laporanService.getLaporanSyahriyah(tahun, kategoriSantri);
        setSyahriyahData(res);
      }
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadActiveTabData();
  }, [activeTab, tahun, bulan, jenisKeuangan, kategoriSantri, statusSantri, statusPendaftaran]);

  const handleResetFilter = () => {
    setTahun(currentYear);
    setBulan('Semua');
    setJenisKeuangan('Semua');
    setKategoriSantri('Semua');
    setStatusSantri('Semua');
    setStatusPendaftaran('Semua');
  };

  // Helper to generate payload (including TOTAL summary row) for exports
  const getCurrentExportPayload = () => {
    const bulanLabel = BULAN_OPTIONS.find((b) => b.value === bulan)?.label || bulan;

    if (activeTab === 'keuangan') {
      const filenameBase = `Laporan-Keuangan-${bulanLabel}-${tahun}`;
      if (!keuanganData || keuanganData.list.length === 0) {
        return { filenameBase, data: [], sheetName: 'Keuangan' };
      }

      const data: Record<string, any>[] = keuanganData.list.map((k) => ({
        Tanggal: k.tanggal,
        Kategori: k.kategori_nama,
        Keterangan: k.keterangan || '-',
        Jenis: k.jenis,
        'Nominal (Rp)': k.nominal,
      }));

      // Append TOTAL row
      data.push({
        Tanggal: 'TOTAL KESELURUHAN',
        Kategori: `${keuanganData.list.length} Transaksi`,
        Keterangan: `Pemasukan: ${formatRupiah(keuanganData.totalPemasukan)} | Pengeluaran: ${formatRupiah(keuanganData.totalPengeluaran)}`,
        Jenis: 'Saldo Bersih',
        'Nominal (Rp)': keuanganData.saldoBersih,
      });

      return { filenameBase, data, sheetName: 'Keuangan' };
    }

    if (activeTab === 'santri') {
      const filenameBase = `Data-Santri-${tahun}`;
      if (santriData.length === 0) {
        return { filenameBase, data: [], sheetName: 'Data Santri' };
      }

      const data: Record<string, any>[] = santriData.map((s) => ({
        NIS: s.nis,
        'Nama Santri': s.nama,
        Kategori: s.kategori,
        Status: s.status,
        'Nama Wali': s.nama_wali,
        'No HP Santri': s.no_hp_santri,
        'No HP Wali': s.no_hp_wali,
        'Tanggal Masuk': s.tanggal_masuk || '-',
      }));

      // Append TOTAL row
      data.push({
        NIS: 'TOTAL SANTRI',
        'Nama Santri': `${santriData.length} Santri`,
        Kategori: '',
        Status: `${santriData.filter((s) => s.status === 'Aktif').length} Aktif`,
        'Nama Wali': '',
        'No HP Santri': '',
        'No HP Wali': '',
        'Tanggal Masuk': '',
      });

      return { filenameBase, data, sheetName: 'Data Santri' };
    }

    if (activeTab === 'pendaftaran') {
      const filenameBase = `Laporan-Pendaftaran-${bulanLabel}-${tahun}`;
      if (pendaftaranData.length === 0) {
        return { filenameBase, data: [], sheetName: 'Pendaftaran' };
      }

      const data: Record<string, any>[] = pendaftaranData.map((p) => ({
        'Tanggal Daftar': p.tanggal_pendaftaran,
        'Nama Calon': p.nama_calon,
        'Nama Wali': p.nama_wali,
        'No HP Santri': p.no_hp_santri,
        'No HP Wali': p.no_hp_wali,
        Kategori: p.kategori,
        Status: p.status,
      }));

      // Append TOTAL row
      data.push({
        'Tanggal Daftar': 'TOTAL PENDAFTAR',
        'Nama Calon': `${pendaftaranData.length} Pendaftar`,
        'Nama Wali': '',
        'No HP Santri': '',
        'No HP Wali': '',
        Kategori: '',
        Status: '',
      });

      return { filenameBase, data, sheetName: 'Pendaftaran' };
    }

    // activeTab === 'syahriyah'
    const filenameBase = `Rekap-Syahriyah-${tahun}`;
    if (syahriyahData.length === 0) {
      return { filenameBase, data: [], sheetName: 'Syahriyah' };
    }

    const data: Record<string, any>[] = syahriyahData.map((r) => ({
      NIS: r.nis,
      'Nama Santri': r.nama,
      Kategori: r.kategori,
      'Total Tagihan (1 Thn)': r.totalTagihan,
      'Total Dibayar': r.totalDibayar,
      'Sisa Tunggakan': r.sisaTunggakan,
      Status: r.statusTahunan,
    }));

    const sumTagihan = syahriyahData.reduce((sum, r) => sum + r.totalTagihan, 0);
    const sumDibayar = syahriyahData.reduce((sum, r) => sum + r.totalDibayar, 0);
    const sumTunggakan = syahriyahData.reduce((sum, r) => sum + r.sisaTunggakan, 0);

    // Append TOTAL row
    data.push({
      NIS: 'TOTAL',
      'Nama Santri': `${syahriyahData.length} Santri`,
      Kategori: '',
      'Total Tagihan (1 Thn)': sumTagihan,
      'Total Dibayar': sumDibayar,
      'Sisa Tunggakan': sumTunggakan,
      Status: '',
    });

    return { filenameBase, data, sheetName: 'Syahriyah' };
  };

  const handleExportCsv = () => {
    const { filenameBase, data } = getCurrentExportPayload();
    exportToCsv(`${filenameBase}.csv`, data);
  };

  const handleExportExcel = () => {
    const { filenameBase, data, sheetName } = getCurrentExportPayload();
    exportToExcel(`${filenameBase}.xlsx`, data, sheetName);
  };

  const getCurrentPdfParams = (): ExportLaporanPdfParams | null => {
    const bulanLabel = BULAN_OPTIONS.find((b) => b.value === bulan)?.label || bulan;

    if (activeTab === 'keuangan') {
      if (!keuanganData || keuanganData.list.length === 0) {
        showToast('Tidak ada data transaksi kas untuk diekspor', 'error');
        return null;
      }

      return {
        title: 'Laporan Rekapitulasi Keuangan Kas',
        subtitle: `Periode: ${bulanLabel} ${tahun}`,
        filename: `Laporan-Keuangan-${bulanLabel}-${tahun}`,
        orientation: 'portrait',
        filterInfo: [
          { label: 'Tahun', value: String(tahun) },
          { label: 'Bulan', value: bulanLabel },
          { label: 'Jenis', value: jenisKeuangan },
        ],
        summaryMetrics: [
          { label: 'TOTAL PEMASUKAN', value: formatRupiah(keuanganData.totalPemasukan) },
          { label: 'TOTAL PENGELUARAN', value: formatRupiah(keuanganData.totalPengeluaran) },
          { label: 'SALDO BERSIH', value: formatSaldo(keuanganData.saldoBersih) },
          { label: 'TOTAL TRANSAKSI', value: `${keuanganData.list.length} Data` },
        ],
        headers: ['No', 'Tanggal', 'Kategori', 'Keterangan', 'Jenis', 'Nominal'],
        rows: keuanganData.list.map((k, idx) => [
          idx + 1,
          k.tanggal,
          k.kategori_nama,
          k.keterangan || '-',
          k.jenis,
          `${k.jenis === 'Pemasukan' ? '+' : '-'} ${formatRupiah(k.nominal)}`,
        ]),
        footers: [
          [
            '',
            '',
            `TOTAL (${keuanganData.list.length} Transaksi)`,
            `Masuk: ${formatRupiah(keuanganData.totalPemasukan)} | Keluar: ${formatRupiah(keuanganData.totalPengeluaran)}`,
            'Saldo Bersih',
            formatSaldo(keuanganData.saldoBersih),
          ],
        ],
        columnStyles: {
          0: { cellWidth: 10, halign: 'center' },
          1: { cellWidth: 22, halign: 'center' },
          2: { cellWidth: 35 },
          3: { cellWidth: 'auto' },
          4: { cellWidth: 22, halign: 'center' },
          5: { cellWidth: 32, halign: 'right' },
        },
      };
    }

    if (activeTab === 'santri') {
      if (santriData.length === 0) {
        showToast('Tidak ada data santri untuk diekspor', 'error');
        return null;
      }

      const aktifCount = santriData.filter((s) => s.status === 'Aktif').length;
      const nonaktifCount = santriData.length - aktifCount;

      return {
        title: 'Laporan Master Data Santri',
        subtitle: `Tahun Akademik: ${tahun}`,
        filename: `Data-Santri-${tahun}`,
        orientation: 'landscape',
        filterInfo: [
          { label: 'Kategori', value: kategoriSantri },
          { label: 'Status', value: statusSantri },
        ],
        summaryMetrics: [
          { label: 'TOTAL SANTRI', value: `${santriData.length} Santri` },
          { label: 'SANTRI AKTIF', value: `${aktifCount} Santri` },
          { label: 'SANTRI TIDAK AKTIF', value: `${nonaktifCount} Santri` },
        ],
        headers: ['No', 'NIS', 'Nama Santri', 'Kategori', 'Status', 'Nama Wali', 'No HP Wali', 'Tanggal Masuk'],
        rows: santriData.map((s, idx) => [
          idx + 1,
          s.nis,
          s.nama,
          s.kategori,
          s.status,
          s.nama_wali || '-',
          s.no_hp_wali || s.no_hp_santri || '-',
          s.tanggal_masuk || '-',
        ]),
        footers: [
          [
            '',
            '',
            `TOTAL: ${santriData.length} Santri`,
            '',
            `${aktifCount} Aktif / ${nonaktifCount} Nonaktif`,
            '',
            '',
            '',
          ],
        ],
        columnStyles: {
          0: { cellWidth: 10, halign: 'center' },
          1: { cellWidth: 24, halign: 'center' },
          2: { cellWidth: 50 },
          3: { cellWidth: 24, halign: 'center' },
          4: { cellWidth: 24, halign: 'center' },
          5: { cellWidth: 45 },
          6: { cellWidth: 35, halign: 'center' },
          7: { cellWidth: 30, halign: 'center' },
        },
      };
    }

    if (activeTab === 'pendaftaran') {
      if (pendaftaranData.length === 0) {
        showToast('Tidak ada data pendaftaran untuk diekspor', 'error');
        return null;
      }

      const baruCount = pendaftaranData.filter((p) => p.status === 'Baru').length;
      const diterimaCount = pendaftaranData.filter((p) => p.status === 'Diterima').length;
      const santriCount = pendaftaranData.filter((p) => p.status === 'Menjadi Santri').length;

      return {
        title: 'Laporan Pendaftaran Santri Baru',
        subtitle: `Periode: ${bulanLabel} ${tahun}`,
        filename: `Laporan-Pendaftaran-${bulanLabel}-${tahun}`,
        orientation: 'landscape',
        filterInfo: [
          { label: 'Tahun', value: String(tahun) },
          { label: 'Bulan', value: bulanLabel },
          { label: 'Status', value: statusPendaftaran },
        ],
        summaryMetrics: [
          { label: 'TOTAL PENDAFTAR', value: `${pendaftaranData.length} Calon` },
          { label: 'STATUS BARU', value: `${baruCount} Calon` },
          { label: 'DITERIMA', value: `${diterimaCount} Calon` },
          { label: 'MENJADI SANTRI', value: `${santriCount} Calon` },
        ],
        headers: ['No', 'Tgl Daftar', 'Nama Calon', 'Nama Wali', 'No HP Calon / Wali', 'Kategori', 'Status'],
        rows: pendaftaranData.map((p, idx) => [
          idx + 1,
          p.tanggal_pendaftaran,
          p.nama_calon,
          p.nama_wali || '-',
          p.no_hp_santri || p.no_hp_wali || '-',
          p.kategori,
          p.status,
        ]),
        footers: [
          [
            '',
            '',
            `TOTAL: ${pendaftaranData.length} Pendaftar`,
            '',
            '',
            '',
            `${diterimaCount + santriCount} Lolos`,
          ],
        ],
        columnStyles: {
          0: { cellWidth: 10, halign: 'center' },
          1: { cellWidth: 30, halign: 'center' },
          2: { cellWidth: 55 },
          3: { cellWidth: 50 },
          4: { cellWidth: 40, halign: 'center' },
          5: { cellWidth: 28, halign: 'center' },
          6: { cellWidth: 35, halign: 'center' },
        },
      };
    }

    // activeTab === 'syahriyah'
    if (syahriyahData.length === 0) {
      showToast('Tidak ada data rekap syahriyah untuk diekspor', 'error');
      return null;
    }

    const sumTagihan = syahriyahData.reduce((sum, r) => sum + r.totalTagihan, 0);
    const sumDibayar = syahriyahData.reduce((sum, r) => sum + r.totalDibayar, 0);
    const sumTunggakan = syahriyahData.reduce((sum, r) => sum + r.sisaTunggakan, 0);
    const lunasCount = syahriyahData.filter((r) => r.statusTahunan === 'Lunas').length;

    return {
      title: 'Laporan Tahunan Syahriyah Santri',
      subtitle: `Tahun: ${tahun}`,
      filename: `Rekap-Syahriyah-${tahun}`,
      orientation: 'landscape',
      filterInfo: [
        { label: 'Tahun', value: String(tahun) },
        { label: 'Kategori Santri', value: kategoriSantri },
      ],
      summaryMetrics: [
        { label: 'TOTAL SANTRI', value: `${syahriyahData.length} Santri` },
        { label: 'TOTAL TAGIHAN (1 THN)', value: formatRupiah(sumTagihan) },
        { label: 'TOTAL TERBAYAR', value: formatRupiah(sumDibayar) },
        { label: 'SISA TUNGGAKAN', value: formatRupiah(sumTunggakan) },
      ],
      headers: ['No', 'NIS', 'Nama Santri', 'Kategori', 'Tagihan 1 Thn', 'Total Dibayar', 'Sisa Tunggakan', 'Status'],
      rows: syahriyahData.map((r, idx) => [
        idx + 1,
        r.nis,
        r.nama,
        r.kategori,
        formatRupiah(r.totalTagihan),
        formatRupiah(r.totalDibayar),
        formatRupiah(r.sisaTunggakan),
        r.statusTahunan,
      ]),
      footers: [
        [
          '',
          '',
          `TOTAL (${syahriyahData.length} Santri)`,
          '',
          formatRupiah(sumTagihan),
          formatRupiah(sumDibayar),
          formatRupiah(sumTunggakan),
          `${lunasCount} Lunas`,
        ],
      ],
      columnStyles: {
        0: { cellWidth: 10, halign: 'center' },
        1: { cellWidth: 25, halign: 'center' },
        2: { cellWidth: 55 },
        3: { cellWidth: 26, halign: 'center' },
        4: { cellWidth: 35, halign: 'right' },
        5: { cellWidth: 35, halign: 'right' },
        6: { cellWidth: 35, halign: 'right' },
        7: { cellWidth: 25, halign: 'center' },
      },
    };
  };

  const handleExportPdf = () => {
    const params = getCurrentPdfParams();
    if (params) {
      exportLaporanToPdf(params);
    }
  };

  const handleOpenPrintPreview = () => {
    const params = getCurrentPdfParams();
    if (!params) return;

    const url = generateLaporanPdfBlobUrl(params);
    if (url) {
      setPreviewPdfUrl(url);
      setPreviewParams(params);
      setPreviewModalOpen(true);
    }
  };

  const handleClosePreviewModal = () => {
    if (previewPdfUrl) {
      URL.revokeObjectURL(previewPdfUrl);
    }
    setPreviewPdfUrl(null);
    setPreviewParams(null);
    setPreviewModalOpen(false);
  };

  return (
    <div className="space-y-6 pb-12">
      <ToastContainer />

      {/* Header Halaman */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-[#0F172A] tracking-tight">
            Laporan & Rekapitulasi
          </h1>
          <p className="text-sm text-slate-500 mt-1">
            Analisis rekapitulasi data pondok dan unduh laporan PDF / Excel / CSV
          </p>
        </div>
      </div>

      {/* Navigation Tabs (Garis Bawah Style) */}
      <div className="border-b border-slate-200">
        <nav className="flex space-x-8 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveTab('keuangan')}
            className={`py-3 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'keuangan'
                ? 'border-[#059669] text-[#059669]'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <Wallet className="w-4 h-4" />
            <span>Rekap Keuangan</span>
          </button>

          <button
            onClick={() => setActiveTab('santri')}
            className={`py-3 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'santri'
                ? 'border-[#059669] text-[#059669]'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>Data Santri</span>
          </button>

          <button
            onClick={() => setActiveTab('pendaftaran')}
            className={`py-3 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'pendaftaran'
                ? 'border-[#059669] text-[#059669]'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <UserPlus className="w-4 h-4" />
            <span>Pendaftaran</span>
          </button>

          <button
            onClick={() => setActiveTab('syahriyah')}
            className={`py-3 text-xs font-semibold border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'syahriyah'
                ? 'border-[#059669] text-[#059669]'
                : 'border-transparent text-slate-500 hover:text-slate-700 hover:border-slate-300'
            }`}
          >
            <CreditCard className="w-4 h-4" />
            <span>Rekap Syahriyah</span>
          </button>
        </nav>
      </div>

      {/* Area Filter Responsive (Card Putih) */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl p-4 shadow-xs space-y-3">
        <div className="flex items-center gap-2 mb-1">
          <Filter className="w-4 h-4 text-[#059669]" />
          <h3 className="text-xs font-bold text-slate-800 uppercase tracking-wider">
            Filter Laporan
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 items-center">
          {/* Tahun Filter (All Tabs) */}
          <div>
            <label className="block text-[11px] font-semibold text-slate-500 mb-1">Tahun</label>
            <select
              value={tahun}
              onChange={(e) => setTahun(Number(e.target.value))}
              className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg outline-none focus:border-[#059669] bg-white text-slate-700 cursor-pointer"
            >
              {[currentYear - 2, currentYear - 1, currentYear, currentYear + 1, currentYear + 2].map((y) => (
                <option key={y} value={y}>
                  {y}
                </option>
              ))}
            </select>
          </div>

          {/* Bulan Filter (Keuangan & Pendaftaran) */}
          {(activeTab === 'keuangan' || activeTab === 'pendaftaran') && (
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Bulan</label>
              <select
                value={bulan}
                onChange={(e) => setBulan(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg outline-none focus:border-[#059669] bg-white text-slate-700"
              >
                {BULAN_OPTIONS.map((b) => (
                  <option key={b.value} value={b.value}>
                    {b.label}
                  </option>
                ))}
              </select>
            </div>
          )}

          {/* Tab Keuangan: Jenis */}
          {activeTab === 'keuangan' && (
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Jenis Transaksi</label>
              <select
                value={jenisKeuangan}
                onChange={(e) => setJenisKeuangan(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg outline-none focus:border-[#059669] bg-white text-slate-700"
              >
                <option value="Semua">Semua Jenis</option>
                <option value="Pemasukan">Pemasukan</option>
                <option value="Pengeluaran">Pengeluaran</option>
              </select>
            </div>
          )}

          {/* Tab Santri / Syahriyah: Kategori */}
          {(activeTab === 'santri' || activeTab === 'syahriyah') && (
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Kategori Santri</label>
              <select
                value={kategoriSantri}
                onChange={(e) => setKategoriSantri(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg outline-none focus:border-[#059669] bg-white text-slate-700"
              >
                <option value="Semua">Semua Kategori</option>
                <option value="Mukim">Mukim</option>
                <option value="Nduduk">Nduduk</option>
                <option value="Kilatan">Kilatan</option>
              </select>
            </div>
          )}

          {/* Tab Santri: Status */}
          {activeTab === 'santri' && (
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Status Santri</label>
              <select
                value={statusSantri}
                onChange={(e) => setStatusSantri(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg outline-none focus:border-[#059669] bg-white text-slate-700"
              >
                <option value="Semua">Semua Status</option>
                <option value="Aktif">Aktif</option>
                <option value="Tidak Aktif">Tidak Aktif</option>
              </select>
            </div>
          )}

          {/* Tab Pendaftaran: Status */}
          {activeTab === 'pendaftaran' && (
            <div>
              <label className="block text-[11px] font-semibold text-slate-500 mb-1">Status Pendaftaran</label>
              <select
                value={statusPendaftaran}
                onChange={(e) => setStatusPendaftaran(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-200 rounded-lg outline-none focus:border-[#059669] bg-white text-slate-700"
              >
                <option value="Semua">Semua Status</option>
                <option value="Baru">Baru</option>
                <option value="Diterima">Diterima</option>
                <option value="Ditolak">Ditolak</option>
                <option value="Menjadi Santri">Menjadi Santri</option>
              </select>
            </div>
          )}

          {/* Action Filter Controls */}
          <div className="flex items-center gap-2 pt-4 sm:pt-0">
            <button
              onClick={handleResetFilter}
              className="inline-flex items-center gap-1 px-3 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 rounded-lg transition-colors border border-slate-200"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Report Table Section */}
      <div className="bg-white border border-[#E2E8F0] rounded-xl shadow-xs overflow-hidden">
        {/* Table Top Header Bar with Side-by-Side Export Buttons */}
        <div className="p-4 border-b border-[#E2E8F0] flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50/60">
          <div>
            <h2 className="text-sm font-bold text-[#0F172A] uppercase tracking-wider">
              {activeTab === 'keuangan' && 'Laporan Rekapitulasi Keuangan'}
              {activeTab === 'santri' && 'Laporan Master Data Santri'}
              {activeTab === 'pendaftaran' && 'Laporan Pendaftaran Santri Baru'}
              {activeTab === 'syahriyah' && 'Laporan Tahunan Syahriyah Santri'}
            </h2>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            {/* Button 1: Export CSV */}
            <button
              onClick={handleExportCsv}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-300 bg-white hover:bg-slate-100 text-slate-700 text-xs font-semibold transition-colors shadow-2xs"
            >
              <Download className="w-3.5 h-3.5 text-slate-500" />
              <span>📄 Export CSV</span>
            </button>

            {/* Button 2: Export Excel (.xlsx) */}
            <button
              onClick={handleExportExcel}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-[#059669] hover:bg-[#047857] text-white text-xs font-semibold transition-colors shadow-2xs cursor-pointer"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>📊 Export Excel</span>
            </button>

            {/* Button 3: Export PDF */}
            <button
              onClick={handleExportPdf}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-700 text-white text-xs font-semibold transition-colors shadow-2xs cursor-pointer"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>📕 Unduh PDF</span>
            </button>

            {/* Button 4: Cetak / Pratinjau */}
            <button
              onClick={handleOpenPrintPreview}
              className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-900 text-white text-xs font-semibold transition-colors shadow-2xs cursor-pointer"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>🖨️ Cetak / Pratinjau</span>
            </button>
          </div>
        </div>

        {/* Tab 1: Rekap Keuangan Special Summary Cards */}
        {activeTab === 'keuangan' && keuanganData && (
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 p-4 border-b border-[#E2E8F0] bg-slate-50/30">
            <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-xl text-xs">
              <span className="text-slate-500 font-medium block">Total Pemasukan</span>
              <span className="text-lg font-bold text-emerald-700 block mt-0.5">
                {formatRupiah(keuanganData.totalPemasukan)}
              </span>
            </div>
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl text-xs">
              <span className="text-slate-500 font-medium block">Total Pengeluaran</span>
              <span className="text-lg font-bold text-red-700 block mt-0.5">
                {formatRupiah(keuanganData.totalPengeluaran)}
              </span>
            </div>
            <div className="p-3 bg-blue-50 border border-blue-200 rounded-xl text-xs">
              <span className="text-slate-500 font-medium block">Saldo Bersih</span>
              <span className="text-lg font-bold text-blue-800 block mt-0.5">
                {formatSaldo(keuanganData.saldoBersih)}
              </span>
            </div>
          </div>
        )}

        {/* Content Render per Tab */}
        {isLoading ? (
          <div className="p-6 space-y-3">
            {[1, 2, 3, 4].map((i) => (
              <div key={i} className="animate-pulse h-10 bg-slate-100 rounded-md" />
            ))}
          </div>
        ) : (
          <div>
            {/* TAB 1: KEUANGAN */}
            {activeTab === 'keuangan' && (
              <div>
                {!keuanganData || keuanganData.list.length === 0 ? (
                  <div className="p-12 text-center space-y-2">
                    <SearchX className="w-12 h-12 text-slate-300 mx-auto" />
                    <p className="text-sm text-slate-500 font-medium">Tidak ada data transaksi kas cocok</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-100 border-b border-[#E2E8F0] font-semibold text-slate-700 uppercase">
                          <th className="px-4 py-3">Tanggal</th>
                          <th className="px-4 py-3">Kategori</th>
                          <th className="px-4 py-3">Keterangan</th>
                          <th className="px-4 py-3">Jenis</th>
                          <th className="px-4 py-3 text-right">Nominal</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {keuanganData.list.map((item) => (
                          <tr key={item.id} className="hover:bg-slate-50">
                            <td className="px-4 py-3 font-mono text-slate-600">{item.tanggal}</td>
                            <td className="px-4 py-3 font-semibold text-[#0F172A]">{item.kategori_nama}</td>
                            <td className="px-4 py-3 text-slate-600 truncate max-w-xs">{item.keterangan || '-'}</td>
                            <td className="px-4 py-3">
                              <span
                                className={`px-2 py-0.5 rounded font-semibold text-[11px] ${
                                  item.jenis === 'Pemasukan'
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                    : 'bg-red-50 text-red-700 border border-red-200'
                                }`}
                              >
                                {item.jenis}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-right font-mono font-bold">
                              {item.jenis === 'Pemasukan' ? (
                                <span className="text-emerald-600">+ {formatRupiah(item.nominal)}</span>
                              ) : (
                                <span className="text-red-600">- {formatRupiah(item.nominal)}</span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      {/* TFOOT TOTAL KEUANGAN */}
                      <tfoot className="bg-slate-100 font-bold text-slate-800 border-t-2 border-slate-300">
                        <tr>
                          <td colSpan={3} className="px-4 py-3 text-left uppercase">
                            TOTAL KESELURUHAN ({keuanganData.list.length} Transaksi)
                          </td>
                          <td className="px-4 py-3">Saldo Bersih</td>
                          <td className="px-4 py-3 text-right font-mono font-extrabold text-[#059669]">
                            {formatSaldo(keuanganData.saldoBersih)}
                          </td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* TAB 2: DATA SANTRI */}
            {activeTab === 'santri' && (
              <div>
                {santriData.length === 0 ? (
                  <div className="p-12 text-center space-y-2">
                    <SearchX className="w-12 h-12 text-slate-300 mx-auto" />
                    <p className="text-sm text-slate-500 font-medium">Tidak ada data santri cocok</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-100 border-b border-[#E2E8F0] font-semibold text-slate-700 uppercase">
                          <th className="px-4 py-3">NIS</th>
                          <th className="px-4 py-3">Nama Santri</th>
                          <th className="px-4 py-3">Kategori</th>
                          <th className="px-4 py-3">Status</th>
                          <th className="px-4 py-3">Nama Wali</th>
                          <th className="px-4 py-3">No HP Wali</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {santriData.map((s) => (
                          <tr key={s.id} className="hover:bg-slate-50">
                            <td className="px-4 py-3 font-mono font-semibold text-slate-700">{s.nis}</td>
                            <td className="px-4 py-3 font-bold text-[#0F172A]">{s.nama}</td>
                            <td className="px-4 py-3 font-medium text-slate-600">{s.kategori}</td>
                            <td className="px-4 py-3">
                              <span
                                className={`px-2 py-0.5 rounded font-semibold text-[11px] ${
                                  s.status === 'Aktif'
                                    ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                                    : 'bg-red-50 text-red-700 border border-red-200'
                                }`}
                              >
                                {s.status}
                              </span>
                            </td>
                            <td className="px-4 py-3 text-slate-600">{s.nama_wali}</td>
                            <td className="px-4 py-3 font-mono text-slate-600">{s.no_hp_wali}</td>
                          </tr>
                        ))}
                      </tbody>
                      {/* TFOOT TOTAL SANTRI */}
                      <tfoot className="bg-slate-100 font-bold text-slate-800 border-t-2 border-slate-300">
                        <tr>
                          <td colSpan={2} className="px-4 py-3 text-left uppercase">
                            TOTAL SANTRI: {santriData.length} Santri
                          </td>
                          <td className="px-4 py-3">
                            {santriData.filter((s) => s.status === 'Aktif').length} Aktif
                          </td>
                          <td className="px-4 py-3">
                            {santriData.filter((s) => s.status === 'Tidak Aktif').length} Tidak Aktif
                          </td>
                          <td colSpan={2} className="px-4 py-3"></td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* TAB 3: PENDAFTARAN */}
            {activeTab === 'pendaftaran' && (
              <div>
                {pendaftaranData.length === 0 ? (
                  <div className="p-12 text-center space-y-2">
                    <SearchX className="w-12 h-12 text-slate-300 mx-auto" />
                    <p className="text-sm text-slate-500 font-medium">Tidak ada data pendaftaran cocok</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-100 border-b border-[#E2E8F0] font-semibold text-slate-700 uppercase">
                          <th className="px-4 py-3">Tgl Daftar</th>
                          <th className="px-4 py-3">Nama Calon</th>
                          <th className="px-4 py-3">Nama Wali</th>
                          <th className="px-4 py-3">No HP</th>
                          <th className="px-4 py-3">Kategori</th>
                          <th className="px-4 py-3">Status</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {pendaftaranData.map((p) => (
                          <tr key={p.id} className="hover:bg-slate-50">
                            <td className="px-4 py-3 font-mono text-slate-600">{p.tanggal_pendaftaran}</td>
                            <td className="px-4 py-3 font-bold text-[#0F172A]">{p.nama_calon}</td>
                            <td className="px-4 py-3 text-slate-600">{p.nama_wali}</td>
                            <td className="px-4 py-3 font-mono text-slate-600">{p.no_hp_santri}</td>
                            <td className="px-4 py-3 font-medium text-slate-600">{p.kategori}</td>
                            <td className="px-4 py-3">
                              <span className="px-2 py-0.5 rounded font-semibold text-[11px] bg-slate-100 text-slate-700 border border-slate-200">
                                {p.status}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      {/* TFOOT TOTAL PENDAFTARAN */}
                      <tfoot className="bg-slate-100 font-bold text-slate-800 border-t-2 border-slate-300">
                        <tr>
                          <td colSpan={2} className="px-4 py-3 text-left uppercase">
                            TOTAL PENDAFTAR: {pendaftaranData.length} Pendaftar
                          </td>
                          <td colSpan={4} className="px-4 py-3"></td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* TAB 4: REKAP SYAHRIYAH */}
            {activeTab === 'syahriyah' && (
              <div>
                {syahriyahData.length === 0 ? (
                  <div className="p-12 text-center space-y-2">
                    <SearchX className="w-12 h-12 text-slate-300 mx-auto" />
                    <p className="text-sm text-slate-500 font-medium">Tidak ada data syahriyah cocok</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-left border-collapse text-xs">
                      <thead>
                        <tr className="bg-slate-100 border-b border-[#E2E8F0] font-semibold text-slate-700 uppercase">
                          <th className="px-4 py-3">NIS</th>
                          <th className="px-4 py-3">Nama Santri</th>
                          <th className="px-4 py-3">Kategori</th>
                          <th className="px-4 py-3 text-right">Tagihan 1 Tahun</th>
                          <th className="px-4 py-3 text-right">Total Dibayar</th>
                          <th className="px-4 py-3 text-right">Sisa Tunggakan</th>
                          <th className="px-4 py-3 text-center">Status Tahunan</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {syahriyahData.map((r) => (
                          <tr key={r.santriId} className="hover:bg-slate-50">
                            <td className="px-4 py-3 font-mono font-semibold text-slate-700">{r.nis}</td>
                            <td className="px-4 py-3 font-bold text-[#0F172A]">{r.nama}</td>
                            <td className="px-4 py-3 text-slate-600 font-medium">{r.kategori}</td>
                            <td className="px-4 py-3 text-right font-mono">{formatRupiah(r.totalTagihan)}</td>
                            <td className="px-4 py-3 text-right font-mono text-emerald-700 font-semibold">
                              {formatRupiah(r.totalDibayar)}
                            </td>
                            <td className="px-4 py-3 text-right font-mono text-red-600 font-semibold">
                              {formatRupiah(r.sisaTunggakan)}
                            </td>
                            <td className="px-4 py-3 text-center">
                              {r.statusTahunan === 'Lunas' && (
                                <span className="px-2 py-0.5 rounded font-semibold text-[11px] bg-emerald-50 text-emerald-700 border border-emerald-200">
                                  Lunas
                                </span>
                              )}
                              {r.statusTahunan === 'Sebagian' && (
                                <span className="px-2 py-0.5 rounded font-semibold text-[11px] bg-amber-50 text-amber-700 border border-amber-200">
                                  Sebagian
                                </span>
                              )}
                              {r.statusTahunan === 'Belum' && (
                                <span className="px-2 py-0.5 rounded font-semibold text-[11px] bg-slate-100 text-slate-500 border border-slate-200">
                                  Belum Bayar
                                </span>
                              )}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                      {/* TFOOT TOTAL SYAHRIYAH */}
                      <tfoot className="bg-slate-100 font-bold text-slate-800 border-t-2 border-slate-300">
                        <tr>
                          <td colSpan={3} className="px-4 py-3 text-left uppercase">
                            TOTAL ({syahriyahData.length} Santri)
                          </td>
                          <td className="px-4 py-3 text-right font-mono">
                            {formatRupiah(
                              syahriyahData.reduce((sum, r) => sum + r.totalTagihan, 0)
                            )}
                          </td>
                          <td className="px-4 py-3 text-right font-mono text-emerald-700">
                            {formatRupiah(
                              syahriyahData.reduce((sum, r) => sum + r.totalDibayar, 0)
                            )}
                          </td>
                          <td className="px-4 py-3 text-right font-mono text-red-600">
                            {formatRupiah(
                              syahriyahData.reduce((sum, r) => sum + r.sisaTunggakan, 0)
                            )}
                          </td>
                          <td className="px-4 py-3"></td>
                        </tr>
                      </tfoot>
                    </table>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Modal Pratinjau Dokumen Cetak */}
      {previewModalOpen && previewPdfUrl && previewParams && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-5 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-full max-w-5xl h-[92vh] flex flex-col overflow-hidden">
            {/* Modal Header */}
            <div className="px-5 py-3.5 border-b border-slate-200 flex items-center justify-between bg-slate-50">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-emerald-50 text-[#059669] border border-emerald-200 flex items-center justify-center shrink-0">
                  <Printer className="w-5 h-5" />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <h3 className="text-base font-bold text-slate-900">
                      Pratinjau Dokumen Cetak
                    </h3>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200 uppercase">
                      A4 • {previewParams.orientation === 'landscape' ? 'Lanskap' : 'Potret'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 mt-0.5">
                    {previewParams.title} {previewParams.subtitle ? `• ${previewParams.subtitle}` : ''}
                  </p>
                </div>
              </div>
              <button
                onClick={handleClosePreviewModal}
                className="p-2 text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 rounded-xl transition-colors cursor-pointer"
                title="Tutup Pratinjau"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body: Embedded PDF viewer */}
            <div className="flex-1 p-3 sm:p-4 bg-slate-100 overflow-hidden flex flex-col">
              <iframe
                src={previewPdfUrl}
                title="Pratinjau Dokumen PDF"
                className="w-full h-full rounded-xl border border-slate-300 bg-white shadow-xs"
              />
            </div>

            {/* Modal Footer */}
            <div className="px-5 py-3 border-t border-slate-200 bg-white flex flex-col sm:flex-row sm:items-center justify-between gap-3">
              <div className="text-xs text-slate-500 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                Format resmi Kop Surat Pondok Pesantren Al Hidayah Tertek siap cetak
              </div>
              <div className="flex items-center gap-2 justify-end">
                <button
                  onClick={handleClosePreviewModal}
                  className="px-4 py-2 text-xs font-semibold text-slate-600 hover:bg-slate-100 border border-slate-200 rounded-lg transition-colors cursor-pointer"
                >
                  Tutup
                </button>
                <button
                  onClick={() => {
                    if (previewParams) printLaporanPdf(previewParams);
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-slate-800 hover:bg-slate-900 text-white rounded-lg transition-colors shadow-2xs cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak Dokumen</span>
                </button>
                <button
                  onClick={() => {
                    if (previewParams) exportLaporanToPdf(previewParams);
                  }}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-rose-600 hover:bg-rose-700 text-white rounded-lg transition-colors shadow-2xs cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh PDF</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LaporanPage;
