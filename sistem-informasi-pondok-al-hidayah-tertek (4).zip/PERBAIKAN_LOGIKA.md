# Perbaikan Logika Bisnis — Sistem Informasi Pondok Al Hidayah

Dokumen ini merangkum perubahan logika bisnis terhadap versi awal, dan mana yang masih perlu keputusan atau pekerjaan lanjutan.

## 1. Data keuangan tidak lagi bisa hilang diam-diam
- Pembacaan localStorage memakai `readJsonStrict` (`src/lib/core.ts`). Jika data rusak, operasi berhenti dan error ditampilkan. Sebelumnya data direset ke kosong/mock lalu tertimpa.
- Data demo (santri, kas, pendaftaran, tarif arsip) hanya dimuat saat `npm run dev`. Build produksi mulai dari data kosong.
- Santri yang sudah punya riwayat pembayaran tidak bisa dihapus; ubah statusnya menjadi Tidak Aktif (riwayat tetap tampil sesuai PRD).

## 2. Pembayaran (syahriyah, kilatan, iuran)
- Semua validasi dijalankan dulu: nominal bilangan bulat rupiah > 0, tidak ada bulan/event ganda dalam satu transaksi, tidak melebihi sisa tagihan, tidak sebelum tanggal masuk.
- Pencatatan kas dan transaksi bersifat satu paket. Jika pencatatan kas gagal, matriks, riwayat, dan nomor kuitansi dikembalikan ke kondisi semula.
- Kas hasil pembayaran diberi penanda sumber dan tidak bisa diedit atau dihapus langsung dari menu Kas. Pembatalan harus dilakukan dari menu asalnya (fitur pembatalan belum dibuat).
- Event kilatan yang tidak dikenal kini ditolak; sebelumnya diabaikan diam-diam.
- Santri kategori Kilatan ditolak jika dicatat sebagai syahriyah bulanan.

## 3. Nomor kuitansi (sesuai PRD)
- Format `AH/tahun/nomor urut`, berurutan per tahun, dibuat hanya setelah transaksi tervalidasi.
- Modal pembayaran dan cetak kwitansi memakai nomor resmi ini, bukan ID internal.

## 4. Tarif (sesuai PRD)
- Default tarif baru berlaku mulai bulan berikutnya.
- Periode tarif tidak boleh di masa lalu.
- Perubahan ditolak jika bulan efektif sudah ada pembayaran.
- Migrasi diam-diam di `getTarif` (mengubah periode `2025-07`) dihapus. Sesuai keputusan PRD, tidak ada migrasi data lama.

## 5. Tunggakan dan laporan
- Tagihan syahriyah hanya dihitung mulai bulan masuk santri sampai bulan berjalan. Sebelumnya bulan sebelum masuk dan bulan mendatang ikut dihitung sebagai tunggakan.
- Tanggal laporan dibaca dari teks `YYYY-MM-DD`, bukan lewat `Date` (sebelumnya bisa bergeser zona waktu).
- Semua tanggal "hari ini" dan "bulan berjalan" memakai zona waktu lokal (WIB). Sebelumnya memakai UTC, sehingga sebelum pukul 07.00 tanggal default bisa menunjuk hari sebelumnya.

## 6. Pendaftaran
- Konversi ke santri hanya untuk pendaftar berstatus Diterima, dan hanya sekali.
- Status "Menjadi Santri" tidak bisa diubah lagi.

## 7. Autentikasi
- Fallback password default (`admin123`) untuk akun yang tidak ditemukan dihapus, sehingga akun yang dihapus tidak bisa login kembali.
- Akun tanpa password tidak bisa dipakai login.

## 8. Keamanan output dan ekspor
- Data santri dan keterangan di kwitansi/kop di-escape sebelum dicetak (mencegah HTML injection).
- Sel Excel/CSV yang diawali `= + - @` diberi apostrof agar tidak dieksekusi sebagai rumus.

## 9. Lain-lain
- Dependensi `react-is` ditambahkan. Tanpanya build produksi gagal.
- Pesan error spesifik (misalnya "riwayat pembayaran") kini tampil di UI, tidak lagi "Gagal menghapus".
- README: password default tidak lagi ditampilkan.

## Keputusan yang perlu Anda konfirmasi
1. **Aturan blokir tarif**: saya memakai bunyi PRD revisi (ditolak jika bulan efektif sudah ada pembayaran). Sebelumnya semua bulan sesudahnya ikut diblokir. Bila ingin lebih ketat, ubah baris `allPaidMonths.includes(newPeriod)` di PengaturanPage.
2. **Urutan NIS otomatis** tetap mulai dari 30 seperti sebelumnya. Bila tidak disengaja, ubah `maxSequence` di pendaftaranService.
3. **Santri Tidak Aktif**: aturan tagihan selama masa tidak aktif belum ditentukan di PRD. Saat ini santri Tidak Aktif tetap ditagihkan sejak bulan masuk.

## Belum dikerjakan / di luar cakupan
- Fitur pembatalan pembayaran (satu-satunya jalan untuk mengoreksi kas hasil pembayaran).
- Cek konfirmasi bendahara, template kuitansi A5 dan thermal, editor kop surat, backup otomatis dan manual, dan alur desain UI dari PRD.
- Modul Dashboard, Laporan (tampilan), Kilatan (tampilan), dan Iuran (tampilan) belum ditelaah baris per baris.
- Kontrol akses masih di sisi klien dan data masih di localStorage. Keduanya perlu backend sebelum dipakai dengan data keuangan nyata.
- Risiko multi-tab: operasi baca-ubah-tulis tanpa kunci bisa saling menimpa.
- `bun.lock` perlu diperbarui dengan `bun install` karena dependensi `react-is` ditambahkan.

## Verifikasi
- `tsc --noEmit`: lolos.
- `vite build`: lolos.
- 14 uji perilaku (pembayaran, rollback, penolakan data rusak, kuitansi berurutan, aturan santri, kilatan, konversi pendaftaran) lolos. Uji dijalankan sementara dan tidak disertakan dalam paket.
